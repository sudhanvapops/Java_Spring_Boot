# Stacks — Library Console · Documentation Set

Frontend specification for a Next.js console built on top of the **Library Management API** (`v3.json`, OpenAPI 3.1.0), styled with the **Obsidian Product System** (`design.md`).

> `Stacks` is a placeholder product name (library vernacular — "the stacks" is where books are shelved). Rename freely; it appears in copy examples throughout.

---

## Reading order

| # | File | What it answers |
|---|------|-----------------|
| 01 | `01-project-overview.md` | What is being built, tech stack, scope, open decisions |
| 02 | `02-pages-required.md` | Every route, its job, layout, states, and copy |
| 03 | `03-endpoints.md` | Full API reference + quirks that affect the UI |
| 04 | `04-data-models.md` | Entities, DTOs, enums, field meanings |
| 05 | `05-auth-spec.md` | Signup / login / reset password — flows and proposed endpoints |
| 06 | `06-validation-rules.md` | Field-by-field rules for Zod schemas |
| 07 | `07-state-management.md` | Zustand store design |
| 08 | `08-api-client.md` | Axios setup, interceptors, error normalisation |
| 09 | `09-error-codes.md` | Backend error codes → user-facing messages |
| 10 | `10-ui-components.md` | Aceternity / Magic UI mapping + design token usage |
| 11 | `11-claude-design-brief.md` | Paste-ready brief for Claude Design |

---

## How to use this with Claude Design

Claude Design works best with a tight brief plus reference material, not a document dump.

**Recommended sequence:**

1. Attach `design.md` (the token system) — this is the visual contract.
2. Attach `11-claude-design-brief.md` — this is the instruction.
3. Attach `02-pages-required.md` and `10-ui-components.md` — these are the scope.
4. Ask for **one screen at a time**. Start with `/login`, then `/dashboard`, then `/books`.
5. Attach `03-endpoints.md` + `04-data-models.md` only when a screen needs real field names and shapes (tables, detail pages, forms).

Do not attach all eleven files at once. The token budget goes to reading instead of designing, and the output gets generic.

---

## Status legend

Used consistently across all files:

| Marker | Meaning |
|--------|---------|
| **CONFIRMED** | Defined in `v3.json`. Safe to build against. |
| **PROPOSED** | Does not exist yet. Backend work required before the frontend can work. |
| **ASSUMED** | Inferred from the spec. Verify with a real request before relying on it. |
| **DECISION** | An open choice. Pick one before building. |

---

## The one-paragraph summary

A librarian signs in, sees what is due today, and moves through four loops: manage the **book catalogue**, manage **members**, **lend** books, and **take them back** (calculating fines). A settings screen controls the three rules the backend enforces — max books per member, max borrow days, and fine per day. Authentication does not exist in the backend yet and is the first thing to build.

---

## No code, by design

These are specification documents. They contain routes, field names, JSON shapes, and rules — no TypeScript, React, or Zod implementation. Everything here is meant to be handed to a design tool or used as a build checklist.
