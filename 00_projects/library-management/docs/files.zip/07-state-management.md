# 07 · State Management

Zustand store design. What belongs in a store, what emphatically doesn't, and how the pieces divide.

---

## The rule that governs everything

**Zustand holds client state. Server data belongs in a cache.**

Server data is a copy of something that lives somewhere else. It goes stale, needs refetching, needs deduplication, needs to know whether it's loading. That's a cache's job, and a state manager is a bad cache.

The moment you put `books: Book[]` in zustand, you've signed up to hand-write: loading flags per resource, error flags per resource, refetch-after-mutation, stale invalidation, request deduplication, and retry. That's TanStack Query, poorly.

**Recommended split:**

| Data | Where | Why |
|------|-------|-----|
| Books, members, records, transactions, settings | **TanStack Query** | Server-owned, cacheable, refetchable |
| Current user + access token | **Zustand** | Client-owned session state |
| Sidebar collapsed, active modal, toasts | **Zustand** | Pure UI |
| The lend basket | **Zustand** | Client-only, spans steps, never on the server until submit |
| The return selection | **Zustand** | Same |
| Table filters, search text, sort | **URL search params** | Shareable, survives refresh, back button works |

**Zustand-only fallback:** if adding a query library isn't wanted, `07` still works — put server data in stores and accept that you're writing cache logic by hand. Budget real time for it, and expect the bugs to be stale-data bugs, which are the annoying kind. The stores below are described so either path works.

---

## Store 1 — Auth

The one store that genuinely must be global.

**State**

| Key | Type | Persisted | Notes |
|-----|------|-----------|-------|
| `user` | Account or null | ✗ | Rehydrated via `/api/auth/me` or refresh |
| `accessToken` | string or null | **✗ never** | Memory only — see `05-auth-spec.md` |
| `status` | `'idle'` · `'loading'` · `'authenticated'` · `'unauthenticated'` | ✗ | Drives the app-shell gate |
| `error` | string or null | ✗ | Last auth failure |

**Actions**

| Action | Does |
|--------|------|
| `login(email, password)` | Calls the endpoint, stores token + user, sets status |
| `signup(payload)` | Same, or routes to the verification screen |
| `logout()` | Calls the endpoint, clears everything, clears the query cache too |
| `refresh()` | Silent token renewal; used on mount and by the 401 interceptor |
| `hydrate()` | On app mount: attempt refresh, resolve status either way |
| `setUser(user)` | Post-profile-update |

**`status` starts at `'idle'`, not `'unauthenticated'`.**

This is the detail that prevents the single most visible auth bug: a flash of the login screen on every page load. Because the access token lives in memory, a refresh always starts with no token. If the initial status says "unauthenticated," the app redirects to `/login` before the refresh call has a chance to succeed. `'idle'` means "we don't know yet" — the shell shows a skeleton and waits.

```
mount → status 'idle'        → shell renders skeleton
      → hydrate() → 'loading'
      → refresh succeeds     → 'authenticated'   → render app
      → refresh fails        → 'unauthenticated' → redirect /login
```

**Never persist this store.** No `persist` middleware, no partial persistence, no "just the user object for a nicer loading state." The moment auth state is on disk, it can disagree with reality — the user object says signed in, the token is gone, and the app is confused in a way that's hard to reproduce.

**On logout, clear the query cache.** Otherwise the next person to sign in on that machine sees the previous user's data for a few frames. Small window, bad look.

---

## Store 2 — Lend basket

Drives `/lend`. Client-only until submit.

**State**

| Key | Type | Notes |
|-----|------|-------|
| `member` | Member or null | Selected in step 1 |
| `items` | Book[] | The basket |
| `submitting` | boolean | |
| `result` | BorrowTransactionResponse or null | Drives the receipt view |

**Actions:** `selectMember` · `clearMember` (also clears items — a different member means a different basket) · `addBook` · `removeBook` · `clear` · `submit`.

**Derived values — computed, never stored:**

| Value | From |
|-------|------|
| `count` | `items.length` |
| `canAdd(book)` | Active, has copies, not already in basket, not already held, within limit |
| `remainingAllowance` | `MAX_BOOKS − booksOut − items.length` |
| `dueDate` | today + `MAX_BORROW_DAYS` |
| `canSubmit` | Member set, active, at least one item |

Storing derived values means keeping them in sync, which means eventually failing to.

**Persist this one? No.** A half-built basket restored three days later is a trap — the librarian doesn't remember it, the availability has changed, and they submit something wrong. If it survives anything, let it be a soft navigation within the session. It should not survive a refresh.

**Clear on success.** After a lend completes, the store holds only `result`. A stale basket behind a receipt is how a librarian lends the same books twice.

---

## Store 3 — Return selection

Drives `/returns`. Same shape, different rules.

**State**

| Key | Type | Notes |
|-----|------|-------|
| `member` | Member or null | |
| `selected` | Set of `bookId` | IDs only — the full records come from the query cache |
| `returnDate` | Date | Defaults to now |
| `submitting` | boolean | |
| `result` | BookReturnResponse or null | |

**Actions:** `selectMember` · `toggle(bookId)` · `selectAll` · `clearSelection` · `setReturnDate` · `submit` · `reset`.

**Derived:**

| Value | From |
|-------|------|
| `estimatedFine` | Σ over selected: `max(0, daysOverdue) × FINE_PER_DAY` |
| `overdueCount` | Selected records past due |
| `canSubmit` | Member set, ≥1 selected, `returnDate ≤ now` |

**Store IDs, not records.** The records live in the query cache keyed by member. Duplicating them here means two copies that can disagree — and the one in the store will be the stale one.

**The estimated fine is an estimate.** Label it as such until the server responds, then show `BookReturnResponse.totalFine`. If they differ, the server wins silently. Don't make the librarian reconcile two numbers.

---

## Store 4 — UI

Small, boring, useful.

| Key | Type | Persisted |
|-----|------|-----------|
| `sidebarCollapsed` | boolean | ✓ localStorage |
| `commandPaletteOpen` | boolean | ✗ |
| `toasts` | Toast[] | ✗ |

**Actions:** `toggleSidebar` · `openCommandPalette` · `closeCommandPalette` · `pushToast` · `dismissToast`.

**Persist only `sidebarCollapsed`.** It's a preference. Everything else is ephemeral and restoring it would be strange — an open command palette on page load helps nobody.

**Toast shape:** `{ id, tone: 'success' | 'error' | 'info', title, description?, action? }`. Auto-dismiss success after 4 seconds; **never auto-dismiss errors** — the person may have looked away, and an error that vanishes is an error that gets repeated.

---

## What does not go in a store

| Not this | Use instead | Why |
|----------|-------------|-----|
| Books, members, records | Query cache | Server-owned |
| Form field values | react-hook-form | Local, high-frequency, re-renders everything if global |
| Table filters and search | URL search params | Shareable, back button, survives refresh |
| Modal open/closed (page-local) | `useState` | Nothing else needs it |
| Derived counts and flags | Compute in a selector | Sync bugs |
| Theme | Nothing — the app is dark-only | Don't build the switch you don't need |

**Filters in the URL, specifically.** `/books?status=inactive&q=refactoring` can be sent to someone, bookmarked, and reloaded. The same state in zustand can't be, and the back button breaks. This is one of those choices that costs nothing now and pays back constantly.

---

## Selector discipline

**Subscribe to the narrowest thing that works.** Reading the whole store re-renders the component on every unrelated change — a toast appearing shouldn't re-render the members table.

Reach for one field per selector. When a component genuinely needs several, use a shallow-equality comparator so a new object identity doesn't trigger a render on its own.

**Slice large stores by concern** and combine them into one store. Keeps the file navigable without spreading state across four providers.

---

## The 401 interceptor's relationship to the auth store

The axios interceptor and the auth store have to cooperate, and this is where circular imports usually appear.

**The problem:** the interceptor needs the token from the store; the store's actions call the API through axios.

**The fix:** the interceptor reads the store through `getState()` at call time rather than importing the hook. No React, no subscription, no cycle.

**The other half:** when a refresh fails, the interceptor must reach *into* the store to clear auth state. Expose a plain `clearAuth()` that touches nothing else, and call it from the interceptor.

Full flow in `08-api-client.md`.

---

## Devtools

Wrap each store in the devtools middleware in development and name it — `auth`, `lend-basket`, `return-selection`, `ui`. Unnamed stores in Redux DevTools all look identical and the tool stops being worth opening.

Strip it in production. It's a small bundle cost and it exposes state shape to anyone with a console.

---

## Store summary

| Store | Purpose | Persisted | Cleared on logout |
|-------|---------|-----------|-------------------|
| `auth` | Session | **Never** | — |
| `lendBasket` | `/lend` workflow | No | ✓ |
| `returnSelection` | `/returns` workflow | No | ✓ |
| `ui` | Chrome and toasts | `sidebarCollapsed` only | Toasts only |

Four stores. If a fifth appears, check first whether it's really server data wearing a disguise.
