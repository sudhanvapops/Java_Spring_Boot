# 06 · Validation Rules

Everything a zod schema needs, described as rules rather than code. One schema per form, plus response schemas for parsing what comes back.

---

## Principles

**Validate at both edges.** Zod on the way out (forms) and on the way in (responses). Parsing responses catches backend drift the moment it happens instead of three components deep as `undefined is not a function`.

**Be stricter than the backend where it's safe.** The API accepts any non-empty string as an email. The frontend shouldn't.

**Never be stricter than the backend where it isn't.** A rule the server doesn't share will reject valid input for no reason.

**Write messages a person can act on.** `Invalid input` tells nobody anything. `Titles can't be longer than 255 characters` tells them exactly what to change.

**Transform at the boundary.** Trim strings, lowercase emails, coerce number inputs from strings, parse setting values. Do it in the schema so it happens once.

**Sensible max lengths, even when the API has none.** The spec sets no upper bound on book titles or member names. Without one, a paste accident becomes a database row nobody can display.

---

## Book form

Used by `/books/new` and `/books/[id]/edit`.

| Field | Type | Rules | Message |
|-------|------|-------|---------|
| `name` (title) | string | Trimmed · required · 1–255 chars | Empty → `Enter the book's title.` Too long → `Titles can't be longer than 255 characters.` |
| `author` | string | Trimmed · required · 1–255 chars | Empty → `Enter the author's name.` |
| `totalCopies` | number | Coerced from input · integer · ≥ 1 · ≤ 10000 | Empty → `Enter how many copies the library owns.` Below 1 → `The library needs at least one copy.` Not whole → `Enter a whole number.` |
| `availableCopies` | number | Coerced · integer · ≥ 0 · ≤ `totalCopies` | Only on edit, read-only. Cross-field: `Available copies can't be more than total copies.` |
| `isActive` | boolean | Not on the form; defaults to `true` on create | — |

**Cross-field rule (edit only):** `availableCopies ≤ totalCopies`. The backend rejects the violation with a `400`, so catching it client-side saves a round trip. Attach the error to `totalCopies` — that's the field the user was editing.

**Warning, not an error:** lowering `totalCopies` below the number currently on loan. The frontend can't reliably compute this (it needs `unreturned/all`), so warn rather than block, and let the backend have the final say.

---

## Member form

Used by `/members/new` and `/members/[id]/edit`.

| Field | Type | Rules | Message |
|-------|------|-------|---------|
| `name` | string | Trimmed · required · 1–120 chars | Empty → `Enter the member's full name.` |
| `email` | string | Trimmed · lowercased · required · valid email · ≤ 254 chars | Empty → `Enter an email address.` Bad format → `That doesn't look like an email address.` |
| `age` | number | Coerced · integer · ≥ 1 · ≤ 120 | Empty → `Enter the member's age.` Out of range → `Enter an age between 1 and 120.` |
| `isActive` | boolean | Not on the form; defaults to `true` | — |

**Uniqueness is a server rule.** `409 MEMBER_EMAIL_ALREADY_EXISTS` comes back after submit — map it onto the email field so it reads like a normal validation error rather than a page-level failure.

**Lowercase the email in the schema.** Otherwise `Priya@example.com` and `priya@example.com` become two members and the uniqueness check silently fails to protect anything.

---

## Auth forms — PROPOSED

### Signup

| Field | Rules | Message |
|-------|-------|---------|
| `name` | Trimmed · required · 2–120 chars | `Enter your name.` |
| `email` | Trimmed · lowercased · valid email · ≤ 254 | `Enter your email address.` / `That doesn't look like an email address.` |
| `password` | 12–128 chars · not in the common-password blocklist · doesn't contain the email local part or the name | See password messages below |
| `confirmPassword` | Must equal `password` | `Passwords don't match.` |
| `acceptTerms` | Must be `true`, if you have terms | `Accept the terms to continue.` |

### Login

| Field | Rules |
|-------|-------|
| `email` | Trimmed · lowercased · required · valid email |
| `password` | Required, non-empty — **no length or strength rules** |
| `rememberMe` | Boolean, defaults false |

**Never apply password rules on login.** If the rules changed since the account was created, a valid password fails client-side and the user is locked out by their own frontend.

### Forgot password

| Field | Rules |
|-------|-------|
| `email` | Trimmed · lowercased · required · valid email |

### Reset password

| Field | Rules |
|-------|-------|
| `token` | From the query string · required · non-empty |
| `password` | Same rules as signup |
| `confirmPassword` | Must equal `password` |

### Change password

| Field | Rules |
|-------|-------|
| `currentPassword` | Required, non-empty |
| `newPassword` | Signup rules · **must differ from `currentPassword`** |
| `confirmPassword` | Must equal `newPassword` |

Same-as-current → `Choose a password you haven't used here before.`

---

## Password rules in detail

| Rule | Value | Message |
|------|-------|---------|
| Minimum length | 12 | `Use at least 12 characters.` |
| Maximum length | 128 | `Passwords can't be longer than 128 characters.` |
| Character classes | **None required** | — |
| Not a common password | Blocklist check | `That password is too common. Pick something less predictable.` |
| Not derived from identity | No email local part, no name | `Don't use your name or email in your password.` |

**No composition requirements, deliberately.** Demanding an uppercase, a digit and a symbol produces `Password1!` — six bits of entropy dressed up as security. A 12-character floor with no other rules produces better passwords in practice. This is what current NIST guidance says; most login forms are still copying the 2005 version.

### Strength meter

Advisory, not a gate. Score 0–4 (a zxcvbn-style estimator is ideal, a heuristic is fine).

| Score | Label | Colour |
|-------|-------|--------|
| 0–1 | Weak | `semantic-danger` |
| 2 | Fair | `semantic-warning` |
| 3 | Good | `semantic-info` |
| 4 | Strong | `semantic-success` |

Always pair the colour with the word. A four-segment bar with no label fails for anyone who can't distinguish red from amber.

Show a live checklist beneath — `At least 12 characters ✓` / `Not a common password ✓` — because people fix what they can see is broken.

---

## Settings form

Three independent schemas — one per card, since each saves on its own.

### `MAX_BOOKS`

| Rule | Value |
|------|-------|
| Type | Integer |
| Range | 1–50 |
| Sent as | String — `5`, not `5.0` |
| Message | `Enter a number between 1 and 50.` |

### `MAX_BORROW_DAYS`

| Rule | Value |
|------|-------|
| Type | Integer |
| Range | 1–365 |
| Sent as | String |
| Message | `Enter a number of days between 1 and 365.` |

### `FINE_PER_DAY`

| Rule | Value |
|------|-------|
| Type | Decimal |
| Range | 0–10000 |
| Precision | 2 decimal places |
| Sent as | String — `10.00` |
| Message | `Enter an amount of 0 or more.` / `Use at most two decimal places.` |

**The value/type contract.** The backend rejects a value that doesn't parse as the setting's `valueType`. Sending `"5.5"` for an `INTEGER` setting is a `400`. The schema must produce a string that parses cleanly on the other side — this is exactly the kind of mismatch that's invisible until it isn't.

---

## Workflow validation

Not form fields — rules the borrow and return screens enforce before allowing submit.

### Lend (`/lend`)

| Rule | Check | Message |
|------|-------|---------|
| Member selected | `memberId` present | `Pick a member first.` |
| Member active | `isActive` | `This member is deactivated and can't borrow.` |
| At least one book | `books.length ≥ 1` | `Add at least one book.` |
| No duplicates in basket | Unique `bookId` | `Already in this basket.` |
| Book is lendable | `isActive && availableCopies > 0` | `No copies available.` / `This book is inactive.` |
| Not already held | Not in `unreturned/{memberId}` | `Priya already has this book out.` |
| Within the limit | `booksOut + basket.length ≤ MAX_BOOKS` | `That's over Priya's limit of 5 books.` |
| Settings configured | `MAX_BOOKS` and `MAX_BORROW_DAYS` exist | `Library rules aren't set up yet.` |

Every one of these maps to a backend error. Checking them client-side turns a failed round trip into an inline hint on the row the user just touched.

### Return (`/returns`)

| Rule | Check | Message |
|------|-------|---------|
| Member selected | `memberId` present | `Pick a member first.` |
| Has books out | `unreturned/{memberId}` non-empty | `Priya has no books out.` |
| At least one selected | `selected.length ≥ 1` | `Tick the books being returned.` |
| Return date not future | `returnDate ≤ now` | `You can't return a book in the future.` |
| Only their books | Every selection came from their unreturned list | Structurally impossible if the UI only offers that list |

---

## Response validation

Zod schemas for what comes *back*, not just what goes out. Every response DTO in `04-data-models.md` gets one.

**In development:** parse strictly and throw loudly. If `BookResponse` arrives without `availableCopies`, you want to know immediately, at the boundary, with a clear message.

**In production:** parse, and on failure log the mismatch and fall back gracefully. A schema drift shouldn't white-screen the app in front of a librarian.

**What this buys you:** the API is generated from a Spring Boot project that's actively being developed. Field names will change. Response parsing turns "some component crashed on Tuesday" into "the API changed and here's the exact field."

**Parse the envelope first**, then the `data` inside it. Two layers, two schemas — `{ success, message, data }` on the outside, the DTO on the inside. See `08-api-client.md`.

---

## Message style

Consistent across every message above.

| Do | Don't |
|----|-------|
| `Enter the book's title.` | `Title is required` |
| `That doesn't look like an email address.` | `Invalid email format` |
| `Use at least 12 characters.` | `Password must be at least 12 characters in length` |
| `Priya already has this book out.` | `BOOK_ALREADY_BORROWED_BY_MEMBER` |

Sentence case. A full stop. Active voice. Say what to do, not what the validator thinks. Never show an error code to a user — put it in the console where it's useful.

Errors don't apologise and they're never vague. `Sorry, something may have gone wrong with your input` is worse than saying nothing.
