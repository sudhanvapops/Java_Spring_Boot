# 08 · API Client

Axios setup, interceptors, and the translation layer between what the backend sends and what the app wants.

---

## Instance configuration

One shared instance. Never call bare `axios` — every request needs the base URL, the token, and the error normalisation.

| Setting | Value | Why |
|---------|-------|-----|
| `baseURL` | `NEXT_PUBLIC_API_BASE_URL` | Never hardcode `localhost:8080` |
| `timeout` | 15000 ms | Unpaginated lists on a cold JVM are slow; 5s is too aggressive |
| `withCredentials` | `true` | Required for the refresh cookie across origins |
| `headers` | `Content-Type: application/json` | |

**A second instance for auth.** `/api/auth/refresh` and `/api/auth/login` need to bypass the interceptors — otherwise a failing refresh triggers a refresh, which fails, which triggers a refresh. A separate bare instance for those two endpoints ends the recursion structurally instead of with a flag.

---

## Environment

| Variable | Example | Notes |
|----------|---------|-------|
| `NEXT_PUBLIC_API_BASE_URL` | `http://localhost:8080` | Public — visible in the browser bundle |
| `NEXT_PUBLIC_CURRENCY_SYMBOL` | `₹` | Fines have no currency field; this is a frontend constant |

Nothing secret goes in a `NEXT_PUBLIC_` variable. If auth ever needs a server-side secret, it lives in a non-public variable and is only read in route handlers.

---

## Request interceptor

Runs before every request.

1. Read `accessToken` from the auth store via `getState()` — not the hook, or you get a circular import.
2. If present, set `Authorization: Bearer …`.
3. In development, log method, URL, and a correlation ID.

Keep it to that. Interceptors that mutate bodies or inject business logic become impossible to reason about once there are three of them.

---

## Response interceptor

Where most of the work happens. Three jobs.

### 1 · Unwrap the envelope

**ASSUMED** — verify with `curl` first, see `03-endpoints.md`.

Responses arrive as `{ success, message, data }`. Components should receive `data`. Unwrap here, once, and no component ever writes `response.data.data`.

Be defensive: if the body has a `success` key, unwrap it; otherwise pass it through. That way the app survives being wrong about the envelope on some endpoints.

### 2 · Normalise errors

Every failure — HTTP error, network drop, timeout, cancelled request — becomes one shape:

| Field | Type | Notes |
|-------|------|-------|
| `status` | number or null | Null when there was no response |
| `errorCode` | string | From the backend, or a synthetic one |
| `message` | string | Backend message; for logs and debugging |
| `userMessage` | string | The sentence a person reads — from `09-error-codes.md` |
| `isEmptyState` | boolean | True when a 404 means "nothing here" rather than "broken" |
| `raw` | unknown | Original error, for the console |

**Synthetic codes** for the cases the backend can't report:

| Situation | Code | `userMessage` |
|-----------|------|---------------|
| No response received | `NETWORK_ERROR` | `Can't reach the server. Check your connection and try again.` |
| Timeout | `TIMEOUT` | `That took too long. Try again.` |
| Request cancelled | `CANCELLED` | — (never shown) |
| Unparseable response | `MALFORMED_RESPONSE` | `The server sent something unexpected.` |

**Two rules for `userMessage`:**

- It is always present. A component should never have to decide what to show.
- It never contains an error code, a stack trace, or a raw backend string. Those go to the console.

### 3 · Flag the empty states

The critical piece. Set `isEmptyState = true` when the status is `404` **and** the `errorCode` indicates absence rather than a missing target.

```
404 + code starts with NO_           → empty state
404 + code is NO_LIBRARY_SETTINGS_…  → empty state
404 + code ends with _NOT_FOUND      → real error
404 + no errorCode at all            → real error
```

Full table in `09-error-codes.md`.

Callers then branch on `isEmptyState`, not on `status === 404`. This single flag is what stops a fresh install from showing error screens on every page.

---

## The 401 refresh flow

The trickiest part of the client. Three requirements: refresh once for many concurrent failures, replay the originals, and never loop.

```
401 arrives
  ↓
Is this the refresh endpoint itself?  → yes → give up, clear auth, redirect
  ↓ no
Has this request already been retried? → yes → give up, clear auth, redirect
  ↓ no
Is a refresh already in flight?
  ├─ yes → queue this request, wait for the result
  └─ no  → start one, mark it in flight
              ↓
        Refresh succeeds
          ├─ store the new token
          ├─ replay the queued requests with it
          └─ replay this one
              ↓
        Refresh fails
          ├─ clear auth state
          ├─ reject everything queued
          └─ redirect to /login?next=<current path>
```

**The three guards, and why each exists:**

| Guard | Prevents |
|-------|----------|
| Refresh endpoint excluded | Infinite recursion when the refresh token itself is dead |
| `_retried` flag per request | A request looping forever against a token that isn't actually fixing anything |
| Single in-flight refresh + queue | Five parallel 401s firing five refreshes — with token rotation, four of them invalidate each other and everyone gets logged out |

That last one is the subtle one. With rotating refresh tokens, concurrent refreshes are actively destructive: each rotation invalidates the previous token, so racing refreshes revoke each other and the user is signed out despite having a perfectly valid session.

**Redirect carefully.** Preserve the current path in `?next=`, and validate it on the login side — accept only paths starting with a single `/`. See `05-auth-spec.md`.

---

## Service layer

Components never call axios directly. One module per domain — books, members, transactions, records, settings, auth — exposing named functions.

| Layer | Responsibility |
|-------|----------------|
| Component | Calls a hook |
| Hook (query/mutation) | Cache keys, loading and error state |
| Service | Endpoint path, params, response parsing, renaming |
| Client | Auth header, envelope, error normalisation |

**Why the service layer earns its keep here:** the API has real awkwardness — `GET /api/book/id/{id}` versus `PUT /api/book/{id}`, `PUT /api/settings` with the key in the body, `book.name` meaning title, settings values as strings. Contain all of it in one file per domain. When the backend changes, one file changes.

**Rename and parse in the service.** `name` → `title`, ISO strings → `Date`, `"5"` → `5`. Components should never see the wire format.

---

## Cache keys

For TanStack Query. Hierarchical, so invalidation can be broad or surgical.

```
['books']                         all books
['books', id]                     one book
['books', 'search', query]        search results
['members']                       all members
['members', id]                   one member
['records', 'unreturned']         everything out
['records', 'unreturned', mid]    one member's
['records', 'due-today']
['transactions']
['transactions', id]
['transactions', 'member', mid]
['settings']
```

**Invalidation after mutations:**

| Mutation | Invalidate |
|----------|-----------|
| Create / update / deactivate book | `['books']` |
| Create / update / deactivate member | `['members']` |
| Lend | `['books']`, `['records']`, `['transactions']`, `['members']` |
| Return | `['books']`, `['records']`, `['members']` |
| Save setting | `['settings']` |

Lending touches nearly everything — availability drops, a record appears, a transaction appears, the member's count changes. Invalidate broadly. Being clever here saves one refetch and costs you a stale availability count, which is the exact number a librarian is about to act on.

**Stale times:**

| Data | Stale after | Reasoning |
|------|-------------|-----------|
| Settings | 5 min | Changes rarely |
| Books, members | 60 s | Changes occasionally |
| Unreturned, due-today | 30 s | The numbers people act on |
| Transactions, records | 60 s | Historical, append-only |

---

## Retries

| Case | Retry? |
|------|--------|
| Network error, timeout | Yes — twice, exponential backoff |
| `5xx` | Once |
| `4xx` | **Never** — a validation failure won't validate on the second attempt |
| `401` | Never at this layer — the refresh flow owns it |
| Any mutation | **Never** automatically |

**Mutations must not auto-retry.** A lend request that times out may well have succeeded. Retrying it lends the books twice. Surface the failure and let the librarian decide — they can see the physical books on the desk and are better placed to judge than a retry policy.

---

## Cancellation

Attach an abort signal to every request that can be superseded: search-as-you-type, filter changes, navigating away mid-load.

Cancelled requests must never surface as errors. Check for the cancellation code early in the error handler and return silently. Otherwise fast typing produces a stack of "request failed" toasts for requests nobody was waiting for.

---

## Loading state

| Duration | Treatment |
|----------|-----------|
| < 200 ms | Nothing. A spinner that flashes is worse than no spinner |
| 200 ms – 2 s | Skeleton matching the final layout |
| > 2 s | Skeleton plus `Still loading…` |
| > 10 s | Offer a cancel action |

**Skeletons, not spinners, for anything with structure.** A skeleton tells you what's coming and stops the layout jumping when it arrives.

**Buttons show their own state.** `Lend 2 books` → `Lending…`, disabled, with a small inline spinner. The page doesn't need to change.

---

## Optimistic updates

Only where a failure is cheap to undo.

| Action | Optimistic? |
|--------|-------------|
| Toggle a filter | Yes — client-side anyway |
| Deactivate a book | Yes — revert on failure with a toast |
| Save a setting | Yes |
| **Lend books** | **No** |
| **Return books** | **No** |

Never for lending or returning. Those change physical reality — a librarian hands over a book because the screen said it worked. Wait for the server. The extra 300 ms is worth it.

---

## Debugging aids

Worth building early on a project where the backend is also under construction.

- **Correlation ID** per request, logged on both sides. Turns "it broke" into "here's the exact request."
- **Response schema logging in development.** When zod parsing fails, log the expected shape and the received shape side by side. This is the fastest way to spot a renamed field.
- **A network status indicator.** A small dot in the topbar that goes `semantic-danger` when the API is unreachable. On localhost against a JVM that restarts constantly, this saves a lot of confused clicking.
