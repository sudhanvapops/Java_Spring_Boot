# 11 · Claude Design Brief

Paste-ready. Start with the master brief, then work screen by screen using the prompts below.

---

## How to run this

**Attach:** `design.md` + this file. Add `02-pages-required.md` when you get to a specific screen.

**Ask for one screen at a time.** A request for "the whole app" produces twelve mediocre screens. A request for one screen produces one good one, and the next screen inherits its decisions.

**Order matters.** Build in this sequence so each screen sets precedent for the next:

1. `/login` — establishes the auth card, inputs, buttons, the background effect
2. App shell — sidebar, topbar, the frame everything else lives in
3. `/dashboard` — stat cards, panels, empty states
4. `/books` — the table pattern, reused by five other screens
5. `/lend` — the most complex screen; do it once the vocabulary exists
6. Everything else

**After each screen,** ask for the empty and error states explicitly. They get skipped otherwise, and they're half the work.

---

## Master brief

> Copy from here.

---

I'm designing **Stacks**, a library management console. Follow the attached `design.md` (the Obsidian Product System) exactly — it's the visual contract, not a suggestion.

**Product:** an internal tool for librarians. One person at a desk, doing four things all day: managing the book catalogue, managing members, lending books out, and taking them back with fines calculated. Not a consumer app, not a marketing site.

**User:** a librarian mid-conversation with someone standing at the counter. Speed and clarity beat delight. They'll use this for hours, every day, for years.

**Tech:** Next.js, Tailwind, shadcn/ui as the base layer, with Aceternity UI and Magic UI available for effects.

**Visual direction — from `design.md`:**
- Dark-first. Canvas `#050506`, layered charcoal surfaces `#101113` / `#151618` / `#1A1B1D`.
- **One accent:** `#4F7CFF`. Interaction only — primary buttons, links, focus rings, selection. Never decoration.
- Hierarchy comes from typography, spacing and surface layering. Not colour, not shadows.
- Geist Sans for display, Inter for interface, JetBrains Mono for IDs, dates and money.
- Radius scale: 4 / 6 / 8 / 12 / 16 / 24. Spacing scale: 4 / 8 / 12 / 16 / 24 / 32 / 48 / 96. Nothing outside these.
- Semantic colours only for status: green `#2DA44E`, amber `#E6A700`, red `#E5484D`.

**Motion budget — this is the constraint that matters most:**

Aceternity and Magic UI are marketing-page libraries. They're in the stack, but they get a strict allowance:

- **Auth screens:** one ambient background effect. One. Low opacity, desaturated toward the blue accent.
- **Dashboard:** number counters on mount, a light staggered entrance. Nothing else.
- **Empty states:** a subtle static pattern.
- **Everywhere else — tables, forms, the lending and returning flows: no motion beyond hover and focus transitions.**

Motion is allowed where the user is arriving, and forbidden where the user is working. A librarian doing forty returns in an afternoon should not see a single animation.

**Copy rules:**
- Sentence case. Full stops. Active voice.
- Buttons say what they do: **Lend 3 books**, **Take books back**, **Save book**. Never "Submit" or "Confirm".
- Empty states are specific and offer an action. `No books match "gibbon"` with a **Clear search** button — not `No results`.
- Errors say what happened and what to do. No apologies, no error codes on screen.
- Name things the way a librarian would: books, members, lending, returns, fines, due dates. Never records, entities, or transactions in user-facing copy.

**Accessibility floor:** visible focus rings on everything, never colour alone for status, 44px minimum touch targets, `prefers-reduced-motion` turns all effects off entirely.

**Design all four states for every screen:** loading (skeletons, never a full-page spinner), empty (specific and actionable), error (states what failed, offers a retry), and loaded.

---

> Copy to here.

---

## Screen prompts

### 1 · `/login`

> Design the sign-in screen for Stacks.
>
> A 420px card centred on the dark canvas: `surface-1`, `rounded.xl`, hairline border, 32px padding. Behind it, one ambient background effect at very low opacity, desaturated toward `#4F7CFF` — Aceternity's Background Beams or similar. Quiet enough that it reads as atmosphere, not as a feature.
>
> Card contents: wordmark, `Welcome back` as the title, `Sign in to the library console.` beneath it. Email and password fields with labels above them, always visible. A `Forgot password?` link inline to the right of the password label. A show/hide toggle in the password field. A `Keep me signed in` checkbox. A full-width `Sign in` button. Below the card: `New here? Create an account`.
>
> Then show me two variants: the error state (a wrong-credentials message above the form reading `That email and password don't match.`) and the pending state (button reading `Signing in…`, disabled).

### 2 · App shell

> Design the application shell — the frame every screen sits inside.
>
> A 240px sidebar on `canvas` with a hairline right border. Wordmark at the top. Navigation grouped under eyebrow labels: **Overview** on its own, then CATALOGUE (Books, Members), CIRCULATION (Lend, Returns, Due today, Currently out), HISTORY (Transactions, Records), then Settings. The active item sits on `surface-2` with a 2px `#4F7CFF` left bar. `Due today` carries a count badge. An account block pinned to the bottom showing name and role.
>
> A 56px topbar on `canvas` with a hairline bottom border: breadcrumb on the left, a `⌘K` search affordance and account menu on the right.
>
> Show it at desktop width, then at 1024px with the sidebar collapsed to icons.

### 3 · `/dashboard`

> Design the dashboard. It answers one question: what needs doing right now?
>
> A greeting header — `Good morning, Priya` with today's date on the right, and one line below: `Four books are due back today.`
>
> A row of four stat cards on `surface-1` at `rounded.xl`: Out on loan (47), Due today (4), Overdue (2), Active members (128). Number in Geist Sans at 40px, label above in 12px `ink-subtle`. The Overdue card turns `#E5484D` and gains a warning icon when the count is above zero.
>
> Below: a "Due back today" panel listing four books, each with title, author, member name and email, and a `Take it back` action. A `View all →` link in the panel header.
>
> Then a quick actions row: `Lend books`, `Take books back`, `Add a book`.
>
> No charts — there's no time-series data behind this and a fake chart is worse than none. Then show me the empty state: nothing due, nothing overdue.

### 4 · `/books`

> Design the book catalogue — this table pattern gets reused across five screens, so it needs to be right.
>
> Page header: `Books` with a one-line subtitle and an `Add a book` button on the right. Below it, a toolbar: a search input, a filter tab row (All / Available / Unavailable / Inactive) using pill tabs, and a result count in 12px on the right.
>
> The table sits directly on the canvas — no card wrapper — with hairline row dividers and a sticky header. Columns: Title, Author, Available/Total, Status, Actions. Availability renders as `3 of 5` in mono with a thin proportional bar beneath it; at zero it turns red and reads `None available`. Status is a pill badge with a dot plus a word. Actions appear on row hover but stay keyboard-reachable. Rows lift to `surface-1` on hover.
>
> Then show me three more states: loading (skeleton rows), empty catalogue (`No books yet` / `Add the first title to your catalogue.` / **Add a book**), and no search matches (`No books match "gibbon"` / **Clear search**). Those last two are different situations and must look different.

### 5 · `/lend`

> Design the lending screen. This is the most-used screen in the app and it has no animation at all.
>
> Three panels. **Panel 1 — Member:** a search field; once someone is picked it collapses to a summary showing their name, email, how many books they already have out, and how many more they're allowed, with a `Change` action. **Panel 2 — Books:** a catalogue search; each result row shows title, author, and availability with an `Add` button. Unavailable and inactive books stay visible but aren't addable, with the reason stated on the row — `None available`, `Inactive`, `Priya already has this book`. **Panel 3 — Confirm:** the basket, the count, the calculated due date, and a button reading `Lend 2 books`.
>
> Number the panels 1, 2, 3 — this genuinely is a sequence and the order carries information.
>
> Then show me the success state: a receipt with the member, the books, the due date, and the transaction ID in mono, with `Print` and `Lend more books` actions.

### 6 · `/returns`

> Design the returns screen.
>
> A member search at the top that collapses to a summary once chosen. Below it, a panel listing every book that member has out, each with a checkbox, title, due date, and fine status — `no fine` in muted text, or `3 days over · ₹30` in red with a warning icon. A select-all checkbox in the panel header.
>
> A totals panel at the bottom: `2 books · fine due ₹30`, the return date (defaulting to today, with a `Change date` action), and a `Take back 2 books` button.
>
> Money in mono with tabular figures. Zero fines read as `no fine`, not `₹0.00`.
>
> Then show me the empty state: a member is selected but has nothing out.

### 7 · `/settings/library`

> Design the library rules screen. Exactly three settings, each in its own card, each saving independently.
>
> **Books per member** — `How many books one member can have out at a time.` — a number input reading 5, unit label `books`, and a Save button.
> **Loan length** — `How long a member can keep a book.` — 14, `days`.
> **Late fee** — `Charged for each day a book is overdue.` — a currency input at 10.00, `per day`.
>
> Under the loan length card, a note in 12px muted text: `Changing this doesn't move existing due dates.`
>
> Then show me an unconfigured card — a setting that's never been created. It needs a `hairline-strong` border, an amber warning icon, and the line `Not set yet — lending is blocked until you set this.`

### 8 · Empty and error states

> Design a set of empty and error states as a single sheet, so they stay consistent:
>
> **Empty:** no books · no members · no transactions · nothing currently out · nothing due today · no search matches · a member with no borrowing history.
> **Error:** can't reach the server · a book that doesn't exist · a permission refusal · a general failure.
>
> Empty states get a subtle static dot pattern behind them. Error states get a `surface-1` panel with a `hairline-strong` border and a red icon. Every one of them: a headline, one line of explanation, and one action.
>
> The empty ones should read like invitations. The error ones should say what happened and what to do, without apologising.

---

## Things to reject

If a design comes back with any of these, push back:

- **A chart.** There's no time-series data in this API. Any chart is decorative and probably fabricated.
- **Animation on tables, forms, `/lend`, or `/returns`.** Outside the budget, no exceptions.
- **More than one background effect on a screen.**
- **A second accent colour.** Obsidian is a one-accent system.
- **Status conveyed by colour alone.** Every state needs an icon or a word.
- **"Submit" or "Confirm" on a button.** Name the action.
- **`No results found` as an empty state.** Too vague to be useful.
- **A light mode.** Not in Phase 1.
- **Placeholder-only form fields.** Labels stay visible.
- **Rounded corners outside the scale**, or spacing outside the scale.
- **A hero section, testimonial block, or pricing card.** This is an internal tool. Those components have no home here.

---

## The test

The design is finished when a librarian, three hours into a Wednesday shift, can lend a book to someone standing in front of them without noticing the interface at all.

Obsidian's own words: *clarity before decoration*, *content is the product*, *calm interfaces age better*. Two flashy component libraries are in the stack. The discipline is knowing that most of the app should show no sign of them.
