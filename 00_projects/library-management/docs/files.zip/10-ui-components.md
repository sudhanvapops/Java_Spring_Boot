# 10 · UI Components

Which components come from where, how the Obsidian tokens map to Tailwind, and — most importantly — where the animated libraries are allowed to appear.

---

## The tension, and how to resolve it

The stack contains a contradiction worth naming before building anything.

**Obsidian says:** *"Don't animate everything."* *"Minimal accent usage."* *"Clarity before decoration."* *"Calm interfaces age better."*

**Aceternity UI and Magic UI are:** libraries of spotlights, meteors, aurora backgrounds, beams, sparkles, and shimmer effects, built for marketing pages that need to stop a scroll.

Magic UI's own documentation describes it as geared toward landing pages and user-facing marketing material. It is **not an application UI library**. Neither is Aceternity's effects catalogue. Used across a librarian's daily workspace, they'd produce a console that's exhausting by Wednesday.

They're still worth having. The resolution is a budget.

### The motion budget

| Zone | Motion allowed | Reasoning |
|------|----------------|-----------|
| **Auth screens** | Generous — one ambient background effect | Seen briefly, once a day. The one place to make an impression. |
| **Dashboard** | Light — number counters, staggered card entrance | Seen at the start of a session, then left behind. |
| **Empty states** | Light — a subtle illustrative effect | Seen rarely; a moment of personality where there's no data to show. |
| **Sidebar, topbar** | Micro only — hover and active transitions | Present all day. Anything more is a tic. |
| **Tables, forms, workflows** | **None beyond state transitions** | This is the work. Motion here is friction wearing a costume. |
| **Lend / Returns** | **None** | The highest-stakes screens. Nothing may compete with the numbers. |

**The rule in one line:** motion is allowed where the user is arriving, and forbidden where the user is working.

> Component names below were accurate as of writing. Both libraries change fast — verify against the current docs before installing. Some Aceternity blocks (login/signup sections, sidebar blocks, empty states) are paid Pro components; the individual effect components are free.

---

## The three-layer component stack

| Layer | Source | Covers |
|-------|--------|--------|
| **Foundation** | shadcn/ui | Button, Input, Label, Select, Checkbox, Dialog, Dropdown, Table, Tabs, Toast, Skeleton, Badge, Command |
| **Application** | Built here | StatCard, DataTable, PageHeader, EmptyState, ErrorPanel, BookRow, MemberRow, AvailabilityBar, FineDisplay, StatusBadge |
| **Effects** | Aceternity / Magic UI | Backgrounds, counters, sidebar, entrance animations — inside the budget above |

shadcn/ui is the foundation both libraries assume. Install it first, restyle it to the Obsidian tokens, and only then reach for effects.

**Restyle, don't accept defaults.** shadcn ships neutral zinc greys. Obsidian's surfaces are specific — `#101113`, `#151618`, `#1A1B1D`. Map them properly at install time or the whole app reads as "default shadcn," which is its own kind of templated.

---

## Token mapping

Every Obsidian token becomes a CSS variable, then a Tailwind utility. No arbitrary hex values in components.

### Colour

| Token | Hex | Used for |
|-------|-----|----------|
| `primary` | `#4F7CFF` | Primary buttons, links, focus, selection |
| `primary-hover` | `#7095FF` | Hover only |
| `primary-focus` | `#3D6CFF` | Focus rings, pressed |
| `canvas` | `#050506` | Page background, sidebar, topbar |
| `surface-1` | `#101113` | Cards, forms, dialogs, row hover |
| `surface-2` | `#151618` | Lifted surfaces, selected tabs, badges |
| `surface-3` | `#1A1B1D` | Nested surfaces |
| `surface-4` | `#1F2023` | Highest elevation |
| `hairline` | `#27292E` | Default borders, table dividers |
| `hairline-strong` | `#373A40` | Emphasised borders, error panels |
| `hairline-tertiary` | `#43464D` | Strongest dividers |
| `ink` | `#F7F8F8` | Primary text |
| `ink-muted` | `#D0D6E0` | Secondary text, labels |
| `ink-subtle` | `#8A8F98` | Tertiary text, helper text |
| `ink-tertiary` | `#62666D` | Disabled, eyebrow labels |
| `success` | `#2DA44E` | Returned on time, saved |
| `warning` | `#E6A700` | Due today, unconfigured settings |
| `danger` | `#E5484D` | Overdue, destructive actions, errors |
| `info` | `#4F7CFF` | Informational — same as primary |

### Type

| Role | Family | Size / weight / tracking | Where |
|------|--------|--------------------------|-------|
| `display-md` | Geist Sans | 40px / 600 / −1px | Auth titles, stat numbers |
| `headline` | Geist Sans | 28px / 600 / −0.6px | Page titles |
| `card-title` | Geist Sans | 22px / 500 / −0.4px | Card headings, wordmark |
| `subhead` | Geist Sans | 20px / 400 / −0.2px | Section headings |
| `body` | Inter | 16px / 400 | Default |
| `body-sm` | Inter | 14px / 400 | Tables, labels, nav |
| `caption` | Inter | 12px / 400 | Helper text, column headers, counts |
| `button` | Inter | 14px / 500 | All buttons |
| `eyebrow` | Inter | 13px / 500 / +0.4px | Sidebar group labels |
| `mono` | JetBrains Mono | 13px / 400 | IDs, timestamps, fines, error refs |

**Mono earns its place here.** IDs, due dates, and fine amounts are things a librarian reads aloud, compares, and copies. Tabular figures stop the digits from dancing between rows.

### Radius and spacing

Radius: `xs 4` · `sm 6` · `md 8` · `lg 12` · `xl 16` · `xxl 24` · `pill 9999`
Spacing: `xxs 4` · `xs 8` · `sm 12` · `md 16` · `lg 24` · `xl 32` · `xxl 48` · `section 96`

Never introduce a value outside these scales. Obsidian is explicit about it, and mixed radii are the fastest way to make a dark UI look sloppy.

---

## Application components

The pieces this app needs that neither library provides. Build these once.

### `PageHeader`
Title (`headline`), optional subtitle (`body-sm`, `ink-subtle`), optional primary action right-aligned. Every `(app)` page starts with one.

### `StatCard`
`surface-1`, `rounded.xl`, 24px padding. Label above (`caption`, `ink-subtle`), number below (`display-md`, Geist Sans). Optional tone for the overdue variant — `semantic-danger` text **and** a warning icon.

### `DataTable`
The most-used component in the app. Sits directly on `canvas`, `hairline` row dividers, sticky header, hover `surface-1`, clickable rows, sortable columns with visible sort state, actions column. Handles all four states internally — loading, empty, error, loaded — so no page reimplements them.

### `EmptyState`
Icon or subtle effect, headline (`subhead`), one line (`body-sm`, `ink-subtle`), one primary action. Centred, 320px max width.

Every empty state gets a **specific** message. `No results` is a wasted screen; `No books match "gibbon"` with a **Clear search** button is a working one.

### `ErrorPanel`
`surface-1`, `hairline-strong` border, `semantic-danger` icon. Message from `09-error-codes.md`, plus **Try again**.

### `StatusBadge`
`status-badge` token — `surface-2`, `ink-muted`, `rounded.pill`, 2px 8px. Variants: Active · Inactive · Out · Returned · Overdue · Due today. **Always a dot or icon plus the word.** Never colour alone.

### `AvailabilityBar`
`3 of 5` in mono, with a thin 3px proportional bar beneath at `rounded.pill`. Fill is `primary`, track is `hairline`. At zero, both number and bar go `semantic-danger` and the label reads `None available`.

### `FineDisplay`
Currency symbol plus amount in mono with tabular figures. Zero renders as `no fine` in `ink-subtle`, not `₹0.00` — the absence of a fine is not a number, it's good news.

### `MemberSearchCombobox` · `BookSearchCombobox`
Used in `/lend` and `/returns`. Built on shadcn's Command. Show the facts needed to choose: for members, name + email + books out; for books, title + author + availability. Unselectable options stay visible with the reason stated.

---

## Aceternity UI — where it's used

### Sidebar — **the strongest fit in the whole stack**

Aceternity's Sidebar expands on hover, is mobile responsive, and supports dark mode out of the box. That's exactly the app shell requirement.

**Restyle it:** `canvas` background, `hairline` right border, active item on `surface-2` with a 2px `primary` left bar. Keep the expand/collapse animation — it's functional motion. Remove any decorative flourish it ships with.

### Auth backgrounds — pick exactly one

The auth card sits on one ambient effect. **One.** Layering two is how a sign-in page starts looking like a screensaver.

| Component | Character | Verdict |
|-----------|-----------|---------|
| **Background Beams** | Slow vertical light beams | **Recommended.** Quiet, directional, doesn't compete with the card. |
| **Aurora Background** | Soft colour wash | Good, if desaturated hard toward the blue accent. |
| **Spotlight** | Single sweep on load | Good — a one-time gesture, then still. |
| **Grid and Dot Backgrounds** | Static pattern | The safest option. Also the most forgettable. |
| Sparkles / Meteors | Particles | Too busy for a login screen. |
| Wavy Background | Animated waves | Reads consumer, not tool. |

Whatever you pick: **very low opacity**, and desaturate toward `primary`. Obsidian is a one-accent system — a rainbow aurora breaks it in the first two seconds a user spends with the product.

### Signup Form

Aceternity's Signup Form is built on shadcn's Input and Label with framer-motion touches — useful as a *reference* for the input focus treatment. Take the interaction detail, not the layout; the auth layout is specified in `02-pages-required.md`.

### Everything else

`3D Card Effect`, `Macbook Scroll`, `Hero Parallax`, `Infinite Moving Cards`, `Globe`, `Lamp Effect`, `Text Reveal Card`, `Typewriter Effect` — all built for marketing pages. **None belong in this app.** If one appears in a librarian's daily workflow, something has gone wrong.

---

## Magic UI — where it's used

### `NumberTicker` — dashboard stats

Counts up on mount. Genuinely good here: it draws the eye to the four numbers that matter, once, at the start of a session.

**Constrain it:** under 800ms, ease-out, and it must respect `prefers-reduced-motion`. A stat that takes two seconds to settle is a stat the librarian has already scrolled past.

### `BlurFade` — staggered entrance

Cards and rows fade in with a small stagger on first load. Makes the dashboard feel assembled rather than dumped.

**Only on first mount.** If it replays on every refetch, the page flickers every 30 seconds and the effect becomes a bug.

### `BorderBeam` — sparingly

A travelling light along a card border. Use it on **at most one** element: the overdue stat card when the count is above zero, or the primary auth card. One instance is a signature; three is decoration.

### `AnimatedList` — due-today feed

Items sliding in as they arrive. Reasonable on the dashboard's due-today panel. Skip it if the list is long — twelve staggered items is a queue, not a flourish.

### `DotPattern` / `GridPattern` — empty states

A subtle background texture behind empty-state copy. Static, low opacity. Fills the void without saying anything.

### `Confetti` — no

Not for lending a book. Celebration effects on routine actions get old on the third use and condescending by the tenth.

### Everything else

`Marquee`, `OrbitingCircles`, `Globe`, `RetroGrid`, `ShimmerButton`, `NeonGradientCard`, `SparklesText`, `WarpBackground`, `Terminal`, `IconCloud` — marketing components. Not here.

---

## Per-page component map

| Page | Foundation | Application | Effects |
|------|-----------|-------------|---------|
| `/login` `/signup` | Input, Label, Button, Checkbox | PasswordField, StrengthMeter | Aceternity **Background Beams** ×1 |
| `/forgot-password` `/reset-password` | Input, Button | — | Same background |
| App shell | Dropdown, Sheet, Command | — | Aceternity **Sidebar** |
| `/dashboard` | Card, Skeleton | StatCard, EmptyState | Magic UI **NumberTicker**, **BlurFade**, conditional **BorderBeam** |
| `/books` `/members` | Table, Input, Tabs, Dropdown | DataTable, StatusBadge, AvailabilityBar, EmptyState | **DotPattern** on empty only |
| `/books/new` `/[id]/edit` | Input, Label, Button, Dialog | — | **None** |
| `/members/new` `/[id]/edit` | Input, Label, Button, Dialog | — | **None** |
| `/lend` | Command, Checkbox, Button, Card | MemberSearchCombobox, BookSearchCombobox, BasketPanel | **None** |
| `/returns` | Command, Checkbox, DatePicker | FineDisplay, UnreturnedList | **None** |
| `/transactions` `/records/*` | Table, Tabs | DataTable, StatusBadge | **None** |
| `/settings/library` | Input, Button, Card, Dropdown | SettingCard | **None** |
| `not-found` `error` | Button | ErrorPanel | **DotPattern** |

**Four of the twelve rows say "None."** That's the point. The screens where the work happens are the screens with no effects at all.

---

## Interaction states

From `design.md`, applied everywhere.

| State | Treatment |
|-------|-----------|
| Hover | Background lifts one surface level. 150ms ease-out. |
| Focus | 2px `primary-focus` ring, 2px offset. **Always visible.** Never removed. |
| Active | Momentary darkening. No scale transforms — they feel cheap at speed. |
| Disabled | `ink-tertiary` text, 50% opacity, `not-allowed` cursor. |
| Loading | Button keeps its width, swaps to a spinner plus present-tense label. |
| Selected | `surface-2` background, `primary` left bar or check. |

**Focus rings are non-negotiable.** Removing an outline for aesthetics makes the app unusable by keyboard. A librarian working a queue at a desk is exactly the person who'd rather not touch a mouse.

---

## Accessibility floor

Meet all of this before calling any screen finished.

- **Contrast.** `ink` on `canvas` is far above AA. `ink-subtle` on `surface-1` is close to the line — check it before using it for anything that must be read, and never for error text.
- **Never colour alone.** Overdue rows get an icon and a day count. Status badges get a dot. The strength meter gets a word.
- **Keyboard.** Every action reachable. Tab order follows visual order. Dialogs trap focus and return it on close. Escape closes.
- **Touch targets.** 44 × 44px minimum, generously spaced. Table action icons need padding, not just an icon.
- **Screen readers.** Tables get proper headers. Icon buttons get labels. Form errors are associated with their fields and announced. Toasts use a live region.
- **Reduced motion.** `prefers-reduced-motion` disables NumberTicker counting, BlurFade staggering, BorderBeam, and every background effect. Not reduced — off. This is a system-level statement of preference, not a suggestion.

---

## Responsive

| Breakpoint | Layout |
|-----------|--------|
| ≥1440 | Full sidebar, multi-column dashboard, all table columns |
| ≥1280 | Full sidebar, standard layout |
| ≥1024 | Sidebar collapses to icons, tables drop the least important column |
| ≥768 | Sidebar becomes a sheet, dashboard stacks to two columns, `/lend` panels stack |
| <768 | Single column, tables become cards, sidebar is a hamburger sheet |

Display type scales `80 → 64 → 40`, `56 → 48 → 32`, `40 → 36 → 28` across desktop, tablet, mobile.

**Tables become cards below 768px, not horizontally scrolling tables.** A horizontally scrolled table on a phone is a table nobody reads.

**Realistically, this app is used on a desktop at a desk.** Mobile should work — a librarian checking due-today from the stacks is a real scenario — but don't spend the design effort there. `/dashboard`, `/records/due-today`, and `/books` are the three that genuinely need to work on a phone.

---

## Before installing anything

1. Set up shadcn/ui and map every Obsidian token to a CSS variable.
2. Restyle the shadcn primitives. Confirm they look like Obsidian, not like default shadcn.
3. Build the application components from the list above.
4. **Only then** add effects, one at a time, checking each against the motion budget.

Doing it in the other order produces an app that looks like three libraries arguing. The token layer has to exist first, or the effects arrive with their own colours and quietly become the design system.
