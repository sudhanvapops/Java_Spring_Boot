# 09 · Error Codes

All 27 error codes the backend can return, what each one should say to a person, and where it appears.

---

## How to use this

The backend returns `errorCode` in every error response. **Branch on the code, never the status.** A `404` can mean "that member doesn't exist" or "that member has no history" — completely different screens, same status.

Every code below maps to:

| Column | Meaning |
|--------|---------|
| **Says** | The exact sentence the user reads |
| **Treatment** | Inline · Toast · Banner · Empty state · Blocking |
| **Recovery** | What action, if any, sits next to the message |

**Treatments:**

| Treatment | When | Looks like |
|-----------|------|------------|
| **Inline** | The error belongs to one field | Below the field, `semantic-danger`, with an icon |
| **Toast** | An action failed but the page is fine | Bottom-right, doesn't auto-dismiss |
| **Banner** | A page-level condition | Top of content, `surface-1` + `hairline-strong` |
| **Empty state** | Nothing is wrong; there's just nothing here | Centred, with a primary action |
| **Blocking** | The screen can't function | Replaces content entirely |

---

## Empty states, not errors

**Read this first.** These codes arrive as `404` but mean "nothing exists yet." Rendering them as errors makes a fresh install look broken.

| Code | Endpoint | Renders as |
|------|----------|-----------|
| `NO_BORROW_TRANSACTIONS_FOUND` | `/borrow-transactions/all`, `/member-id/{id}` | Empty state |
| `NO_BORROW_RECORDS_FOUND` | `/borrowrecord/all`, `/member-id/{id}` | Empty state |
| `NO_UNRETURNED_BOOKS_FOUND` | `/borrowrecord/unreturned/*` | Empty state |
| `NO_LIBRARY_SETTINGS_AVAILABLE` | `/settings/all` | "Not configured" state |
| *(no code)* | `GET /api/book` returning 404 | Empty state |

**The rule for the axios interceptor:**

```
404 + errorCode starts with NO_          → isEmptyState = true
404 + errorCode is NO_LIBRARY_SETTINGS_… → isEmptyState = true
404 + errorCode ends with _NOT_FOUND     → isEmptyState = false
404 + no errorCode                       → isEmptyState = false, log it
```

**The ambiguous case that will bite you:** `GET /api/borrowrecord/member-id/{id}` returns `404` for both a missing member and a member with no records. `MEMBER_NOT_FOUND` → real error, show the not-found screen. `NO_BORROW_RECORDS_FOUND` → empty panel on an otherwise working page. Two very different outcomes behind one status code.

---

## Members

### `MEMBER_NOT_FOUND` · 404

**Says:** `That member doesn't exist.`
**Treatment:** Blocking on `/members/[id]`. Toast elsewhere.
**Recovery:** **Back to members**

Usually a stale link or a bad URL. On a detail page, replace the content — don't show an empty profile.

### `MEMBER_INACTIVE` · 409

**Says:** `Priya's account is deactivated and can't borrow books.`
**Treatment:** Blocking on `/lend` step 1. Banner on `/members/[id]`.
**Recovery:** **Reactivate member**

Use the member's actual name. `The member is inactive` reads like a system message; `Priya's account is deactivated` reads like information.

### `MEMBER_EMAIL_ALREADY_EXISTS` · 409

**Says:** `That email is already registered.`
**Treatment:** Inline on the email field.
**Recovery:** **View that member** — link to the existing record.

The most common create-member failure. The link matters: the librarian is usually about to discover this person is already registered.

### `MEMBER_HAS_ACTIVE_BORROWS` · 409

**Says:** `Priya still has 2 books out. Take them back before deactivating.`
**Treatment:** Toast, or inline in the deactivate dialog.
**Recovery:** **Go to returns**

Include the count if you have it — it's the difference between a blocker and a next step.

---

## Books

### `BOOK_NOT_FOUND` · 404

**Says:** `That book doesn't exist.`
**Treatment:** Blocking on `/books/[id]`. Toast elsewhere.
**Recovery:** **Back to books**

### `BOOK_INACTIVE` · 409

**Says:** `This book is inactive and can't be lent.`
**Treatment:** Inline on the row in `/lend`. Banner on `/books/[id]`.
**Recovery:** **Reactivate book**

Preventable — the lend screen should never offer an inactive book as addable.

### `BOOK_NOT_AVAILABLE` · 409

**Says:** `No copies of this book are available.`
**Treatment:** Inline on the row, Add button disabled.
**Recovery:** None. Add **See who has it** if you want to be helpful — the data is in `unreturned/all`.

Also preventable client-side. If it reaches the server, two librarians lent the last copy at the same moment — worth a specific message: `Someone just lent the last copy.`

### `BOOK_ALREADY_EXISTS` · 409

**Says:** `A book with this title and author already exists.`
**Treatment:** Inline, spanning title and author — the pair is what conflicts, not either field.
**Recovery:** **View that book**

Often the right move is to raise `totalCopies` on the existing record rather than create a duplicate. Say so: `Add copies to the existing record instead?`

### `INVALID_BOOK_COPIES` · 400

**Says:** `Available copies can't be more than total copies.`
**Treatment:** Inline on `totalCopies`.
**Recovery:** None — the user fixes the number.

Catch this in zod. It should never reach the server.

### `BOOK_CURRENTLY_BORROWED` · 409

**Says:** `This book is out on loan. It has to come back before you can deactivate it.`
**Treatment:** Toast, or inline in the deactivate dialog.
**Recovery:** **See who has it**

---

## Borrowing

### `BORROW_TRANSACTION_NOT_FOUND` · 404

**Says:** `That transaction doesn't exist.`
**Treatment:** Blocking on `/transactions/[id]`.
**Recovery:** **Back to transactions**

### `NO_BORROW_TRANSACTIONS_FOUND` · 404 → **empty state**

**On `/transactions`:** `No transactions yet` / `Lending a book will create the first one.` / **Lend books**
**On `/members/[id]`:** `Priya hasn't borrowed anything yet.`

Not an error. Never render it as one.

### `MAX_BOOK_LIMIT_EXCEEDED` · 400

**Says:** `That's over Priya's limit of 5 books. Remove one first.`
**Treatment:** Inline in the lend basket, Add disabled.
**Recovery:** None — remove a book.

Name the limit. `Limit exceeded` makes the librarian go and look it up; `limit of 5 books` doesn't.

Compute the remaining allowance up front and show it in step 1 so this rarely fires.

### `DUPLICATE_BOOK_REQUEST` · 400

**Says:** `Already in this basket.`
**Treatment:** Inline on the row, Add disabled.
**Recovery:** None.

Should be structurally impossible — the basket is a set. If it reaches the server, there's a bug in the UI.

### `BOOK_ALREADY_BORROWED_BY_MEMBER` · 409

**Says:** `Priya already has this book out.`
**Treatment:** Inline on the row, Add disabled.
**Recovery:** None. Optionally show the due date — that's usually the next question.

Preventable via `unreturned/{memberId}`, which the lend screen already loads.

---

## Returns

### `BORROW_RECORD_NOT_FOUND` · 404

**Says:** `That borrow record doesn't exist.`
**Treatment:** Toast.
**Recovery:** **Refresh**

Rare. Usually means the data on screen is stale.

### `NO_BORROW_RECORDS_FOUND` · 404 → **empty state**

**On `/records`:** `No records yet` / `Records appear here once books start going out.`
**On `/members/[id]`:** `No borrowing history yet.`

### `NO_UNRETURNED_BOOKS_FOUND` · 404 → **empty state**

**On `/records/unreturned`:** `Nothing is out` / `Every book is on the shelf.`
**On `/returns`:** `Priya has no books out.` / `Nothing to take back.`

The all-clear, not a failure. It should read like good news.

### `NO_ACTIVE_BORROWED_BOOKS` · 400

**Says:** `Priya has no books out.`
**Treatment:** Blocking on `/returns` after member selection.
**Recovery:** **Pick a different member**

### `BOOK_NOT_BORROWED_BY_MEMBER` · 400

**Says:** `Priya doesn't have this book out.`
**Treatment:** Toast + refresh the unreturned list.
**Recovery:** **Refresh**

Means the screen is stale — someone returned it in another session. Refetch rather than arguing with the user.

### `INVALID_RETURN_DATE` · 400

**Says:** `You can't return a book in the future.`
**Treatment:** Inline on the date picker.
**Recovery:** None.

Prevent it by capping the picker at today.

---

## Settings

### `NO_LIBRARY_SETTINGS_AVAILABLE` · 404 → **"not configured" state**

**On `/settings/library`:** show all three cards in their unconfigured state. Not an error — a to-do list.
**On `/lend`:** blocking — `Library rules aren't set up yet.` / `Set the borrowing limits before lending books.` / **Go to settings**

**This is the code that makes a fresh install look broken.** With no settings, lending fails with a `404` that superficially reads as "member not found." Check settings on mount of `/lend` and `/returns` and say the real thing.

### `SETTING_NOT_FOUND` · 404

**Says:** `That setting hasn't been created yet.`
**Treatment:** Card switches to its unconfigured state.
**Recovery:** The card's Save now uses `POST` instead of `PUT`.

The direct consequence of the create/update split. If it fires, the screen's knowledge of which settings exist is stale — reload `/api/settings/all` and re-render.

### `INVALID_SETTING_VALUE` · 400

**Says:** `Enter a whole number.` (INTEGER) / `Enter an amount with at most two decimal places.` (DECIMAL)
**Treatment:** Inline on the card's input.
**Recovery:** None.

The value didn't parse as the setting's `valueType`. Zod should catch it first — `06-validation-rules.md` has the per-key rules.

### `SETTING_ALREADY_EXISTS` · 409

**Says:** Nothing. Don't show this one.
**Treatment:** Retry as `PUT` automatically, then reload settings.
**Recovery:** Silent.

The user asked to save a value. Whether that's a create or an update is the app's problem, not theirs. Handle it and move on.

---

## General

### `VALIDATION_FAILED` · 400

**Says:** Depends on the field — map the backend's message onto the relevant input where possible. Fallback: `Check the highlighted fields and try again.`
**Treatment:** Inline where the field is identifiable, banner otherwise.
**Recovery:** None.

Zod should catch nearly everything first. When this fires, the schemas and the backend disagree — worth logging with the payload so the gap can be closed.

### `INTERNAL_SERVER_ERROR` · 500

**Says:** `Something went wrong on the server. Try again in a moment.`
**Treatment:** Toast, or banner if the page can't render.
**Recovery:** **Try again**

**One special case:** a `500` from `PATCH /api/book/{id}/activate` almost certainly means the book was already active — the spec documents the missing handler. Translate it: `This book is already active.` Everywhere else, keep it generic.

Never show a stack trace or a raw server message. Log it with a correlation ID and show the sentence above.

---

## Auth codes — PROPOSED

For when the endpoints in `05-auth-spec.md` exist.

| Code | Status | Says | Treatment |
|------|--------|------|-----------|
| `INVALID_CREDENTIALS` | 401 | `That email and password don't match.` | Above the form — **never** on a single field |
| `ACCOUNT_INACTIVE` | 403 | `This account has been deactivated. Ask an administrator to restore it.` | Above the form |
| `EMAIL_NOT_VERIFIED` | 403 | `Confirm your email first.` | Above the form + **Resend the link** |
| `ACCOUNT_ALREADY_EXISTS` | 409 | `That email already has an account.` | Inline on email + **Sign in instead** |
| `TOKEN_EXPIRED` | 401 | `This link has expired.` | Blocking + **Request a new link** |
| `TOKEN_INVALID` | 401 | `This reset link isn't valid.` | Blocking + **Request a new link** |
| `TOKEN_ALREADY_USED` | 401 | `This link has already been used.` | Blocking + **Request a new link** |
| `PASSWORD_TOO_WEAK` | 400 | `Use at least 12 characters.` | Inline + strength checklist |
| `RATE_LIMIT_EXCEEDED` | 429 | `Too many attempts. Try again in 5 minutes.` | Above the form, submit disabled with a countdown |
| `UNAUTHORIZED` | 401 | — | Silent: refresh, then redirect |
| `FORBIDDEN` | 403 | `You don't have access to this.` | Blocking — **don't** redirect to login |

**`INVALID_CREDENTIALS` goes above the form, not on a field.** Attaching it to the password field tells an attacker the email was valid.

**`FORBIDDEN` is not `UNAUTHORIZED`.** The user is signed in and simply isn't allowed. Bouncing them to a login screen they're already past is confusing and doesn't help.

---

## Client-side codes

Generated by the axios layer, not the backend.

| Code | Says | Treatment |
|------|------|-----------|
| `NETWORK_ERROR` | `Can't reach the server. Check your connection and try again.` | Banner + **Try again** |
| `TIMEOUT` | `That took too long. Try again.` | Toast + **Try again** |
| `CANCELLED` | — | Never shown |
| `MALFORMED_RESPONSE` | `The server sent something unexpected.` | Toast; log the schema mismatch |

`NETWORK_ERROR` is the one he'll see most during development — the Spring app restarts constantly. Make it clearly distinguishable from a real API error, or debugging gets slow.

---

## Message rules

Every message in this file follows these:

1. **Plain language.** No codes, no jargon, no `DTO`, no HTTP status.
2. **Say what happened**, not what the system did. `No copies are available` beats `Request failed`.
3. **Say what to do next** whenever there is a next step.
4. **Use real names.** `Priya already has this book` beats `The member already has this book`.
5. **Never apologise.** `Sorry, an error occurred` is filler where information should be.
6. **Sentence case, full stop, active voice.**
7. **Codes go to the console**, never to the screen.

The test: read the message aloud to someone who has never used the app. If they know what to do, it's finished.
