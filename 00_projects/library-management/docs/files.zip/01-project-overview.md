# 01 · Project Overview

## What this is

A Next.js frontend for an existing Spring Boot library management API. The backend already handles books, members, borrowing, returns, fines, and configurable library rules. The frontend adds the interface — and adds authentication, which the backend does not have.

**Primary user:** a librarian at a desk, working through the same handful of tasks all day.
**Secondary user (Phase 2):** a library member checking what they have out and when it's due.

**The console's single job:** make lending and returning fast enough that the librarian doesn't think about the software.

---

## Tech stack

| Layer | Choice | Notes |
|-------|--------|-------|
| Framework | Next.js (App Router) | Route groups for `(auth)` and `(app)` |
| Language | TypeScript | Strict mode |
| HTTP | **axios** | Single instance + interceptors — see `08-api-client.md` |
| State | **zustand** | Auth, UI, and two workflow carts — see `07-state-management.md` |
| Validation | **zod** | Shared between forms and API response parsing — see `06-validation-rules.md` |
| Forms | react-hook-form + zod resolver | Recommended pairing; not mandated |
| Base components | shadcn/ui | The foundation both UI libraries assume |
| Effects | **Aceternity UI** | Auth screens, sidebar, empty states |
| Effects | **Magic UI** | Dashboard accents, number counters, subtle motion |
| Styling | Tailwind CSS | Obsidian tokens mapped to CSS variables |
| Data fetching | **DECISION** — see below | TanStack Query vs. plain axios in effects |

### Fonts (from `design.md`)

| Role | Family | Use |
|------|--------|-----|
| Display | Geist Sans | Headings, page titles, stat numbers |
| Interface | Inter | Body, labels, buttons, tables |
| Mono | JetBrains Mono | IDs, ISBNs, timestamps, error codes, fine amounts |

---

## Backend reality check

The API is `http://localhost:8080` in the spec. Five things about it shape the entire frontend:

**1. There is no authentication.** Every endpoint is open. Nothing in `v3.json` mentions tokens, sessions, or roles. All auth in this documentation set is marked **PROPOSED** and needs backend work first.

**2. There is no pagination.** `GET /api/book`, `GET /api/member`, `GET /api/borrowrecord/all` return everything. Filtering, sorting, and paging are the frontend's job. Fine at a few hundred rows; plan a virtualised table if the catalogue grows past a few thousand.

**3. Empty is often a 404, not an empty list.** Most collection endpoints return `404` when nothing exists rather than `200 []`. The frontend must translate specific 404s into empty states, not error screens. The per-endpoint table in `03-endpoints.md` marks which ones.

**4. Members are records, not accounts.** `MemberRequest` is `{ name, email, age, isActive }`. No password, no login. A member cannot sign in today.

**5. The response envelope is inconsistent in the spec.** Success responses reference bare DTOs (`BookResponse`); error responses reference wrappers (`ApiResponseBookResponse`). Almost certainly the backend wraps everything in `{ success, message, data }` and the generator lost it. **ASSUMED:** always wrapped. Verify with one real request before writing the axios response interceptor.

```
curl -i http://localhost:8080/api/member
```

If that returns `{"success":true,"message":"...","data":[...]}`, the assumption holds.

---

## Scope

### Phase 1 — Librarian console (this spec)

- Authentication: sign up, log in, forgot password, reset password, change password
- Dashboard with due-today and at-a-glance counts
- Book catalogue: list, search, create, edit, deactivate, reactivate
- Members: list, search, create, edit, deactivate, reactivate
- Borrow flow: pick member → add books → confirm
- Return flow: pick member → select unreturned → see fine → confirm
- Transactions and records browsing
- Library settings (three keys)

### Phase 2 — Member portal (specced, not detailed)

- Member self-service: my borrowed books, my history, my due dates
- Requires linking auth accounts to member records
- Requires backend changes to scope responses by the caller's own ID

### Explicitly out of scope

- Reservations / holds, book cover images, ISBN lookup, notifications, reports, multi-branch, payment collection for fines. The API supports none of these.

---

## Open decisions

Settle these before building. Each one changes the shape of the code.

**DECISION 1 — Who can sign up?**
An open signup form on a library admin tool means anyone can create a librarian account. Options: (a) open signup, first user becomes admin, subsequent users need approval; (b) invite-only, admin creates accounts; (c) open signup but new accounts land in a pending state. Recommendation: **(a)** for a practice project, **(b)** for anything real.

**DECISION 2 — Do auth accounts link to member records?**
If yes, add `memberId` (nullable) to the account. This is what makes Phase 2 possible. Cheap to add now, painful to retrofit. Recommendation: **add the nullable column now, ignore it in Phase 1.**

**DECISION 3 — Token storage.**
Recommendation: access token in memory (zustand, not persisted), refresh token in an httpOnly cookie. Details and the simpler fallback are in `05-auth-spec.md`.

**DECISION 4 — Server Components or client-only?**
The API is a separate origin with bearer tokens, which makes RSC data fetching awkward. Recommendation for Phase 1: **client-side fetching throughout**, App Router used for routing and layouts only. Revisit if SEO or first-paint ever matters — for an internal console, it doesn't.

**DECISION 5 — TanStack Query or not?**
Zustand is a state manager, not a cache. Without a query layer you hand-roll loading flags, refetch-on-mutate, and stale data. Recommendation: **use TanStack Query for server data, zustand for client state only** (auth, UI, the borrow/return carts). If you'd rather keep the stack small, `07-state-management.md` describes the zustand-only fallback and what it costs you.

---

## Non-negotiables

Carried from `design.md` and applied throughout:

- **Dark-first.** Canvas `#050506`, layered charcoal surfaces. No light mode in Phase 1.
- **One accent.** `#4F7CFF` for interaction only — primary actions, links, focus, selection. Not for decoration.
- **Hierarchy from type and spacing**, not colour.
- **Never colour alone.** Every status carries an icon or a label as well.
- **Motion serves understanding.** The design system says "don't animate everything." Two flashy component libraries are in this stack; `10-ui-components.md` defines exactly where they're allowed.
- **44 × 44px minimum touch targets.** Spacing tokens only — no arbitrary values.
