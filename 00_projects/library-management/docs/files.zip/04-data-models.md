# 04 · Data Models

Every shape the API sends or expects, plus what the fields actually mean.

---

## Domain model

```
Account (PROPOSED)          Member                    Book
├ id                        ├ id                      ├ id
├ name                      ├ name                    ├ name  ← the title
├ email                     ├ email                   ├ author
├ passwordHash              ├ age                     ├ totalCopies
├ role                      └ isActive                ├ availableCopies
├ isActive                        │                   └ isActive
└ memberId (nullable) ────────────┘                         │
                                  │                         │
                                  ▼                         │
                        BorrowTransaction                   │
                        ├ transactionId                     │
                        ├ memberName                        │
                        ├ borrowDate                        │
                        └ books[] ──────────────────────────┘
                                  │
                                  ▼
                          BorrowRecord
                          ├ borrowedBookId
                          ├ memberId
                          ├ dueDate
                          └ returned / fine
```

**One transaction, many records.** Lending three books at once creates one transaction and three records. Returns operate on records, not transactions — a member can bring back one of three books.

**`memberId` on Account is DECISION 2.** Nullable, unused in Phase 1, the hinge for the Phase 2 member portal.

---

## Conventions

| Convention | Detail |
|-----------|--------|
| IDs | `int64` for `id`, `memberId`, `bookId`, `transactionId`. Treat as opaque; display in mono. |
| Ages, copies | `int32` |
| Money | `number` (`totalFine`, `fine`). Never format with float arithmetic — round at display. |
| Dates | ISO 8601 date-time strings, e.g. `2026-08-04T10:15:30Z` |
| Booleans | `isActive` only |
| Settings values | **Always strings**, typed separately by `valueType` |
| Naming | `name` means *title* on a book and *person's name* on a member. Rename to `title` in the frontend's own types — `book.name` reads wrong everywhere it appears in UI code. |

---

## Books

### `BookRequest` — sent on create and update

| Field | Type | Required | Constraint | UI treatment |
|-------|------|----------|-----------|--------------|
| `name` | string | ✓ | min length 1 | **Title** field |
| `author` | string | ✓ | min length 1 | **Author** field |
| `totalCopies` | int32 | ✓ | ≥ 1 | Number stepper, default 1 |
| `availableCopies` | int32 | ✓ | ≥ 0 | **Hidden on create** (send = total) · **read-only on edit** |
| `isActive` | boolean | ✓ | — | **Never on the form.** Send `true`; changed via deactivate/activate only |

Only two of the five fields belong on the create form. The other three are schema requirements, not user decisions.

### `BookResponse`

| Field | Type | Notes |
|-------|------|-------|
| `id` | int64 | Path param for edit/delete |
| `name` | string | Title |
| `author` | string | Free text — no author entity, so `"Hunt & Thomas"` and `"Andrew Hunt"` are unrelated strings. Author search is exact-ish matching against whatever was typed. |
| `availableCopies` | int32 | Falls as books go out, rises as they return |
| `totalCopies` | int32 | What the library owns |
| `isActive` | boolean | False = soft-deleted |

**Derived for display:**

| Value | How |
|-------|-----|
| On loan now | `totalCopies − availableCopies` |
| Can be lent | `isActive && availableCopies > 0` |
| Availability label | `0` → `None available` · else `3 of 5 available` |

---

## Members

### `MemberRequest`

| Field | Type | Required | Constraint | UI treatment |
|-------|------|----------|-----------|--------------|
| `name` | string | ✓ | min length 1 | **Full name** |
| `email` | string | ✓ | min length 1 | **Email** — spec only requires non-empty; enforce real email format client-side |
| `age` | int32 | ✓ | ≥ 1 | **Age** |
| `isActive` | boolean | ✓ | — | **Never on the form.** Send `true` |

The email constraint is `minLength: 1` — the backend does not appear to validate format. Do it properly in the frontend; a typo'd member email means a reminder that never arrives.

### `MemberResponse`

| Field | Type | Notes |
|-------|------|-------|
| `id` | int64 | |
| `name` | string | |
| `email` | string | Unique — the 409 on create proves it |
| `age` | int32 | |
| `isActive` | boolean | False = can't borrow |

**Derived for display:** books out (count from `unreturned/all` grouped by `memberId`) · remaining allowance (`MAX_BOOKS` − books out) · has overdue (any unreturned record with `dueDate < now`).

---

## Borrowing

### `BorrowTransactionRequest`

| Field | Type | Required | Constraint |
|-------|------|----------|-----------|
| `memberId` | int64 | ✓ | |
| `books` | array | ✓ | at least 1 item |
| `books[].bookId` | int64 | ✓ | |

`books` is an array of objects, not an array of IDs. `[{ "bookId": 42 }]`, not `[42]`. Easy to get wrong.

### `BorrowTransactionResponse`

| Field | Type | Notes |
|-------|------|-------|
| `transactionId` | int64 | Show in mono on the receipt |
| `memberName` | string | Name only — **no `memberId` at this level** |
| `borrowDate` | date-time | |
| `books` | `BorrowTransactionItemResponse[]` | |

**Awkward shape:** `memberId` is missing from the transaction root but repeated on every item inside `books[]`. To link a transaction back to a member, read it from `books[0].memberId`. Handle the empty-array case defensively.

### `BorrowTransactionItemResponse`

| Field | Type | Notes |
|-------|------|-------|
| `memberId` | int64 | Duplicated per item |
| `memberName` | string | Duplicated per item |
| `borrowedBookId` | int64 | The book's ID — **not** a record ID |
| `bookName` | string | Title |
| `author` | string | |
| `dueDate` | date-time | Set at lending time from `MAX_BORROW_DAYS` |

**This type does double duty.** It's the item inside a transaction *and* the response type for `/api/borrowrecord/all`, `/member-id/{id}`, `/unreturned/all` and `/unreturned/{id}`.

**What's missing matters:** no record ID, no `returnDate`, no `returned` flag, no fine. So from a records list you cannot tell whether a book came back — you infer it from *which endpoint you called*. Records from `/unreturned/*` are out; records from `/all` are a mix with no way to distinguish them.

**Consequence for `/records`:** the "Returned / Out" filter can't be built from `/all` alone. Either call both `/all` and `/unreturned/all` and diff them on `(memberId, borrowedBookId)`, or ask the backend to add a `returned` flag. **The second is the right fix** — the diff breaks the moment a member borrows the same title twice.

### `DueTodayResponse`

| Field | Type | Notes |
|-------|------|-------|
| `borrowedBookId` | int64 | |
| `bookName` | string | |
| `author` | string | |
| `dueDate` | date-time | |
| `memberId` | int64 | |
| `memberName` | string | |
| `memberEmail` | string | **Unique to this type** — no other response carries it |

The email is why `/records/due-today` can offer a "copy all emails" action and nothing else can.

---

## Returns

### `BookReturnRequest`

| Field | Type | Required | Notes |
|-------|------|----------|-------|
| `memberId` | int64 | — | Not marked required in the schema, but needed in practice |
| `books` | array | ✓ | min 1 item, `{ bookId }` objects |
| `returnDate` | date-time | — | Defaults to now. **Must not be in the future** |

### `BookReturnResponse`

| Field | Type | Notes |
|-------|------|-------|
| `memberId` | int64 | |
| `memberName` | string | |
| `totalFine` | number | Authoritative — overrides any client estimate |
| `books` | `BorrowReturnItemResponse[]` | |

### `BorrowReturnItemResponse`

| Field | Type | Notes |
|-------|------|-------|
| `bookId` | int64 | |
| `bookName` | string | |
| `fine` | number | Per book; `0` when on time |
| `returnDate` | date-time | Echoes what was sent, or now |

Currency has no field. `FINE_PER_DAY` is a bare number, so the symbol is a frontend constant. Put it somewhere obvious and don't scatter `₹` through the components.

---

## Settings

### `SettingsResponseDto`

| Field | Type | Notes |
|-------|------|-------|
| `settingKey` | enum | `MAX_BOOKS` · `MAX_BORROW_DAYS` · `FINE_PER_DAY` |
| `settingValue` | string | Always a string |
| `description` | string | Set at creation, not editable via `PUT` |
| `valueType` | enum | `STRING` · `INTEGER` · `BOOLEAN` · `DECIMAL` |

### `CreateSettingRequestDto` — for `POST`

| Field | Required | Constraint |
|-------|----------|-----------|
| `settingKey` | ✓ | enum |
| `valueType` | ✓ | enum |
| `settingValue` | ✓ | max 255 chars |
| `description` | — | max 255 chars |

### `SettingsRequestDto` — for `PUT`

| Field | Required |
|-------|----------|
| `settingKey` | ✓ |
| `settingValue` | ✓ |

`valueType` and `description` can't be changed after creation. Get them right the first time.

### The three settings

| Key | Type | Meaning | Sensible default | UI |
|-----|------|---------|------------------|-----|
| `MAX_BOOKS` | `INTEGER` | Books one member may hold at once | `5` | Number, 1–50 |
| `MAX_BORROW_DAYS` | `INTEGER` | Loan length; sets `dueDate` at lending time | `14` | Number, 1–365 |
| `FINE_PER_DAY` | `DECIMAL` | Charged per overdue day per book | `10.00` | Currency, ≥ 0, 2 decimals |

`valueType` allows `STRING` and `BOOLEAN` but none of the three keys use them. Don't build a generic type-switching editor for cases that can't occur.

**Changing `MAX_BORROW_DAYS` doesn't move existing due dates** — the value is read at the moment of lending. Say this on the settings screen.

---

## Account — PROPOSED

Doesn't exist yet. Shapes for the backend work.

### Account

| Field | Type | Notes |
|-------|------|-------|
| `id` | int64 | |
| `name` | string | |
| `email` | string | Unique, lowercased on write |
| `passwordHash` | string | BCrypt. Never leaves the server |
| `role` | enum | `LIBRARIAN` · `MEMBER` |
| `isActive` | boolean | |
| `emailVerified` | boolean | |
| `memberId` | int64 | Nullable — DECISION 2 |
| `createdAt` | date-time | |

### `AuthResponse` — from login and refresh

| Field | Type | Notes |
|-------|------|-------|
| `accessToken` | string | JWT, short-lived (~15 min) |
| `expiresIn` | int | Seconds |
| `user` | object | `id`, `name`, `email`, `role`, `memberId` |

The refresh token is **not** in the body — it's set as an httpOnly cookie. If it appears in JSON, the storage strategy in `05-auth-spec.md` has been undone.

### Password reset token

| Field | Type | Notes |
|-------|------|-------|
| `token` | string | Cryptographically random, ≥ 32 bytes, single-use |
| `accountId` | int64 | |
| `expiresAt` | date-time | 30 minutes |
| `usedAt` | date-time | Nullable — set on use so the token can't be replayed |

---

## Frontend type notes

Not code — decisions about how these shapes should be represented.

**Rename at the boundary.** `book.name` → `book.title`, `record.borrowedBookId` → `record.bookId`. Do it once in the API layer so awkward server naming doesn't leak into every component.

**Parse dates at the boundary too.** Strings in, `Date` objects out. Mixing the two is a reliable source of bugs.

**Parse setting values at the boundary.** `"5"` → `5`. Components should never see the string form.

**Derive, don't store.** `booksOut`, `isOverdue`, `remainingAllowance` and `canBeLent` are computed from server data. Keeping them in state means keeping them in sync, which means eventually getting it wrong.

**Model records honestly.** Given that `BorrowTransactionItemResponse` has no `returned` flag, don't invent one on the type and quietly guess. Either get the backend to add it or make the ambiguity explicit in the type so every consumer has to think about it.
