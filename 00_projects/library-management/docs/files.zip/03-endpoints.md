# 03 · Endpoints

Complete reference for the Library Management API, derived from `v3.json` (OpenAPI 3.1.0), plus the auth endpoints that need to be built.

**Base URL:** `http://localhost:8080` — put this in `NEXT_PUBLIC_API_BASE_URL`, never hardcode it.
**Content type:** `application/json` throughout.
**Auth:** none currently. Every endpoint below is publicly callable.

---

## Response envelope

**ASSUMED.** The spec is inconsistent — success responses reference bare DTOs, error responses reference `ApiResponse*` wrappers. The backend almost certainly wraps everything and springdoc lost it in generation.

Assume every response looks like this:

```json
{
  "success": true,
  "message": "Book created",
  "data": { }
}
```

And errors like this:

```json
{
  "success": false,
  "errorCode": "BOOK_NOT_FOUND",
  "message": "No book exists with id 42",
  "timestamp": "2026-08-04T10:15:30Z"
}
```

**Verify before building the axios interceptor:**

```
curl -i http://localhost:8080/api/member
curl -i http://localhost:8080/api/book/id/999999
```

If the first returns a bare array, the envelope assumption is wrong and `08-api-client.md` needs adjusting. Do this first — it affects every request in the app.

---

## The 404-as-empty problem

**Read this before building any list screen.**

Most collection endpoints return `404` when nothing exists, rather than `200` with an empty array. If the client treats every 404 as an error, a brand-new library shows error screens on every page instead of empty states.

| Endpoint | Nothing found → | Client must render |
|----------|-----------------|--------------------|
| `GET /api/member` | `200` + empty list | Empty state |
| `GET /api/borrowrecord/due-today` | `200` + empty list | Empty state |
| `GET /api/book` | **`404`** | Empty state |
| `GET /api/book/name` | **`404`** | "No matches" state |
| `GET /api/book/author` | **`404`** | "No matches" state |
| `GET /api/borrow-transactions/all` | **`404`** | Empty state |
| `GET /api/borrow-transactions/member-id/{id}` | **`404`** | Empty panel |
| `GET /api/borrowrecord/all` | **`404`** | Empty state |
| `GET /api/borrowrecord/member-id/{id}` | **`404`** | Empty panel |
| `GET /api/borrowrecord/unreturned/all` | **`404`** | Empty state |
| `GET /api/borrowrecord/unreturned/{id}` | **`404`** | Empty panel |
| `GET /api/settings/all` | **`404`** | "Not configured" state |

**The ambiguity that matters:** on `/api/borrowrecord/member-id/{memberId}`, a `404` means *either* "no such member" *or* "member has no records." The `errorCode` disambiguates — `MEMBER_NOT_FOUND` vs `NO_BORROW_RECORDS_FOUND`. Branch on the code, never on the status alone.

**Rule for the app:** a 404 whose `errorCode` starts with `NO_` is an empty state. A 404 whose code ends in `_NOT_FOUND` is a real miss. See `09-error-codes.md` for the full mapping.

---

## Books

**CONFIRMED** · Tag: `Books`

### `GET /api/book`
List every book.

| | |
|---|---|
| Params | none |
| `200` | `BookResponse[]` |
| `404` | `NO books exist` → empty state |

---

### `POST /api/book`
Add a book.

**Body** — `BookRequest`
```json
{ "name": "The Pragmatic Programmer", "author": "Hunt & Thomas", "totalCopies": 5, "availableCopies": 5, "isActive": true }
```

| Code | Meaning |
|------|---------|
| `201` | Created → `BookResponse` |
| `400` | Validation failed, or `availableCopies` exceeds `totalCopies` |
| `409` | `BOOK_ALREADY_EXISTS` — same name *and* author already present |

**UI note:** `availableCopies` and `isActive` are required by the schema but should not be on the create form. Send `availableCopies = totalCopies` and `isActive = true`.

---

### `GET /api/book/id/{id}`
One book.

| | |
|---|---|
| Path | `id` — integer (int64) |
| `200` | `BookResponse` |
| `404` | `BOOK_NOT_FOUND` |

**Note the path shape.** It's `/api/book/id/{id}`, not `/api/book/{id}`. But `PUT` and `DELETE` *do* use `/api/book/{id}`. Easy to get wrong — the read and write paths differ.

---

### `GET /api/book/name?name=…`
Search by title.

| | |
|---|---|
| Query | `name` — string, **required** |
| `200` | `BookResponse[]` |
| `404` | No match → "no results", not an error |

### `GET /api/book/author?author=…`
Search by author. Same shape, same 404 behaviour.

---

### `PUT /api/book/{id}`
Update a book. Full replacement — send every field.

**Body** — `BookRequest`

| Code | Meaning |
|------|---------|
| `200` | Updated |
| `400` | Validation, or available > total |
| `404` | `BOOK_NOT_FOUND` |
| `409` | Book is inactive, or another book already has this name + author |

---

### `DELETE /api/book/{id}`
Deactivate — a **soft delete**. The row stays; `isActive` flips to false.

| Code | Meaning |
|------|---------|
| `200` | Deactivated |
| `404` | `BOOK_NOT_FOUND` |
| `409` | Already inactive, or `BOOK_CURRENTLY_BORROWED` |

Call it "Deactivate" in the UI, never "Delete". The word sets the wrong expectation for a reversible action.

---

### `PATCH /api/book/{id}/activate`
Reactivate.

| Code | Meaning |
|------|---------|
| `200` | Reactivated |
| `404` | `BOOK_NOT_FOUND` |
| `500` | **Already active** — the spec itself notes no handler is wired up |

**Handle the 500.** The spec documents this as a known gap. If the UI ever calls activate on an already-active book, it gets a server error. Two defences: disable the action when `isActive` is already true, and translate a 500 from *this specific endpoint* into `This book is already active.` rather than a generic failure.

---

## Members

**CONFIRMED** · Tag: `Members`

### `GET /api/member`
List every member.

| | |
|---|---|
| `200` | `MemberResponse[]` — empty list when none exist |

One of only two endpoints that returns an empty array instead of a 404.

---

### `POST /api/member`
Register a member.

**Body** — `MemberRequest`
```json
{ "name": "Priya Nair", "email": "priya@example.com", "age": 34, "isActive": true }
```

| Code | Meaning |
|------|---------|
| `201` | Created |
| `400` | Validation failed |
| `409` | `MEMBER_EMAIL_ALREADY_EXISTS` |

**This is not signup.** It creates a library record with no password and no ability to sign in. Naming it "Register a new member" in the spec is misleading in an app that also has real user accounts. Keep the two concepts visibly separate in the UI.

---

### `GET /api/member/{id}` · `PUT /api/member/{id}`

| Code | Meaning |
|------|---------|
| `200` | Found / updated |
| `400` | Validation (PUT only) |
| `404` | `MEMBER_NOT_FOUND` |
| `409` | Member inactive, or another member has that email (PUT only) |

---

### `DELETE /api/member/{id}`
Deactivate — soft delete.

| Code | Meaning |
|------|---------|
| `200` | Deactivated |
| `404` | `MEMBER_NOT_FOUND` |
| `409` | Already inactive, or `MEMBER_HAS_ACTIVE_BORROWS` |

The 409 is common and needs specific handling — see `/members/[id]/edit` in `02-pages-required.md`.

---

### `PATCH /api/member/{id}/activate`

| Code | Meaning |
|------|---------|
| `200` | Reactivated |
| `404` | `MEMBER_NOT_FOUND` |

Note: unlike the book equivalent, no documented 500 for already-active. Behaviour is probably the same though — guard the UI anyway.

---

## Borrow Transactions

**CONFIRMED** · Tag: `Borrow Transactions`
A *transaction* is one lending event covering one or more books.

### `POST /api/borrow-transactions/borrow`
Lend books.

**Body** — `BorrowTransactionRequest`
```json
{ "memberId": 17, "books": [ { "bookId": 42 }, { "bookId": 87 } ] }
```
`books` requires at least one item.

**Response** — `BorrowTransactionResponse`
```json
{
  "transactionId": 301,
  "memberName": "Priya Nair",
  "borrowDate": "2026-08-04T10:15:30Z",
  "books": [
    { "memberId": 17, "memberName": "Priya Nair", "borrowedBookId": 42,
      "bookName": "The Pragmatic Programmer", "author": "Hunt & Thomas",
      "dueDate": "2026-08-18T10:15:30Z" }
  ]
}
```

| Code | Causes |
|------|--------|
| `201` | Lent |
| `400` | Validation · `DUPLICATE_BOOK_REQUEST` · `MAX_BOOK_LIMIT_EXCEEDED` · malformed setting value |
| `404` | `MEMBER_NOT_FOUND` · `BOOK_NOT_FOUND` · **a required library setting isn't configured** |
| `409` | `MEMBER_INACTIVE` · `BOOK_INACTIVE` · `BOOK_NOT_AVAILABLE` · `BOOK_ALREADY_BORROWED_BY_MEMBER` |

**The settings dependency is the surprising one.** If `MAX_BOOKS` or `MAX_BORROW_DAYS` has never been created, lending returns `404` — which looks like "member not found" if you only read the status code. Check settings on mount of `/lend` and block the screen with a clear message rather than letting the librarian fail at the last step.

**Every 400 and 409 here is preventable client-side.** The guard rails in `/lend` exist for exactly this.

---

### `GET /api/borrow-transactions/all` · `/{id}` · `/member-id/{memberId}`

| Endpoint | `200` | `404` |
|----------|-------|-------|
| `/all` | `BorrowTransactionResponse[]` | No transactions → empty state |
| `/{id}` | one transaction | `BORROW_TRANSACTION_NOT_FOUND` |
| `/member-id/{memberId}` | that member's transactions | Member missing **or** no transactions — check `errorCode` |

---

## Borrow Records

**CONFIRMED** · Tag: `Borrow Records`
A *record* is one book on loan. A transaction of three books produces three records.

### `POST /api/borrowrecord/return`
Take books back, calculate fines, restore availability.

**Body** — `BookReturnRequest`
```json
{ "memberId": 17, "books": [ { "bookId": 42 } ], "returnDate": "2026-08-04T10:15:30Z" }
```

`returnDate` is **optional** and defaults to now. Only `books` is strictly required by the schema, though `memberId` is obviously needed in practice.

**Response** — `BookReturnResponse`
```json
{
  "memberId": 17,
  "memberName": "Priya Nair",
  "totalFine": 30.0,
  "books": [
    { "bookId": 42, "bookName": "Designing Data-Intensive Applications",
      "fine": 30.0, "returnDate": "2026-08-04T10:15:30Z" }
  ]
}
```

| Code | Causes |
|------|--------|
| `200` | Returned |
| `400` | Validation · duplicates · `NO_ACTIVE_BORROWED_BOOKS` · `BOOK_NOT_BORROWED_BY_MEMBER` · `INVALID_RETURN_DATE` (future) · malformed fine setting |
| `404` | `MEMBER_NOT_FOUND` · `FINE_PER_DAY` not configured |
| `409` | `MEMBER_INACTIVE` |

**`totalFine` from the server is authoritative.** The UI's live fine preview is a convenience; when the response comes back, show its numbers.

**Future dates are rejected.** Cap the date picker at today rather than surfacing a 400.

---

### `GET /api/borrowrecord/all`
Every record ever. Returns `BorrowTransactionItemResponse[]`.

### `GET /api/borrowrecord/member-id/{memberId}`
One member's records. `404` for missing member *or* no records — check the code.

### `GET /api/borrowrecord/unreturned/all`
Everything currently on loan. **The workhorse endpoint** — `/dashboard`, `/books/[id]`, `/members`, `/records/unreturned` and the `/lend` guard rails all derive from it. Fetch once, cache, share.

### `GET /api/borrowrecord/unreturned/{memberId}`
One member's outstanding books. Drives `/returns`.

> Spring resolves the literal `/unreturned/all` before the `{memberId}` pattern, so the two coexist safely. Just never let a member ID be the string `all`.

### `GET /api/borrowrecord/due-today`
Records due back today. Returns `DueTodayResponse[]` — **the only endpoint that includes `memberEmail`**, which is what makes reminder workflows possible.

Returns `200` with an empty list when nothing is due. No 404. Well-behaved.

---

## Library Settings

**CONFIRMED** · Tag: `Library Settings`

Three keys, fixed by enum: `MAX_BOOKS`, `MAX_BORROW_DAYS`, `FINE_PER_DAY`.

### `GET /api/settings/all`
| `200` | `SettingsResponseDto[]` |
| `404` | `NO_LIBRARY_SETTINGS_AVAILABLE` — nothing configured yet |

### `GET /api/settings/{key}`
| Path | `key` — one of the three enum values |
| `200` | `SettingsResponseDto` |
| `404` | `SETTING_NOT_FOUND` |

### `POST /api/settings`
Create. **Fails if the key already exists.**

```json
{ "settingKey": "MAX_BOOKS", "valueType": "INTEGER", "settingValue": "5", "description": "Books a member can hold at once" }
```

| `201` | Created |
| `400` | Validation, or the value doesn't parse as the given `valueType` |
| `409` | `SETTING_ALREADY_EXISTS` |

### `PUT /api/settings`
Update. **Fails if the key doesn't exist.** Note there's no `{key}` in the path — it's in the body.

```json
{ "settingKey": "MAX_BOOKS", "settingValue": "7" }
```

| `200` | Updated |
| `400` | Validation, or the value doesn't match the setting's existing `valueType` |
| `404` | `SETTING_NOT_FOUND` |

### `DELETE /api/settings/{key}`
| `200` | Deleted |
| `404` | `SETTING_NOT_FOUND` |

**Deleting a setting breaks lending or returns.** Bury it behind an overflow menu with a blunt confirmation.

**The POST/PUT split forces a read-first pattern.** The settings screen must know which of the three keys exist before it can save anything. Load `/api/settings/all` on mount and keep that knowledge in state.

**Values are strings.** `"5"`, not `5`. `valueType` tells you how to parse. Convert at the edge — parse on the way in, stringify on the way out — so the rest of the app works with real numbers.

---

## Auth endpoints — PROPOSED

None of these exist. All need building in the Spring Boot backend before any auth screen works. Full behaviour is in `05-auth-spec.md`; this is the contract summary.

| Method | Path | Purpose | Auth |
|--------|------|---------|------|
| `POST` | `/api/auth/signup` | Create an account | Public |
| `POST` | `/api/auth/login` | Exchange credentials for tokens | Public |
| `POST` | `/api/auth/logout` | Invalidate the refresh token | Bearer |
| `POST` | `/api/auth/refresh` | New access token from a refresh token | Cookie |
| `GET` | `/api/auth/me` | Current account | Bearer |
| `POST` | `/api/auth/forgot-password` | Email a reset link | Public |
| `POST` | `/api/auth/reset-password` | Set a new password using a token | Token |
| `POST` | `/api/auth/change-password` | Change while signed in | Bearer |
| `POST` | `/api/auth/verify-email` | Confirm an address | Token |
| `POST` | `/api/auth/resend-verification` | Send the link again | Public |

**Suggested error codes** to extend the existing `ErrorCode` enum, keeping the backend's established pattern:

```
INVALID_CREDENTIALS      ACCOUNT_INACTIVE        EMAIL_NOT_VERIFIED
ACCOUNT_ALREADY_EXISTS   TOKEN_EXPIRED           TOKEN_INVALID
TOKEN_ALREADY_USED       PASSWORD_TOO_WEAK       PASSWORD_MISMATCH
RATE_LIMIT_EXCEEDED      UNAUTHORIZED            FORBIDDEN
```

Two status codes the frontend doesn't handle today but will need to: **`401`** (token missing or expired → refresh, then redirect to login) and **`403`** (signed in but not allowed → show a permission message, don't redirect).

---

## Endpoint quirks — the short list

Worth keeping in one place.

1. **Book read path differs from write path** — `GET /api/book/id/{id}` vs `PUT|DELETE /api/book/{id}`.
2. **`PUT /api/settings` has no path param** — the key lives in the body.
3. **`PATCH /api/book/{id}/activate` returns 500 when already active** — documented gap, needs a client-side guard.
4. **Settings values are strings**, typed by a separate `valueType` field.
5. **No pagination anywhere.** Every list is a full table scan over the wire.
6. **Most empty collections are 404s**, two are `200 []`. Never assume.
7. **`POST /api/member` is not signup** despite the wording.
8. **Lending fails with 404 when settings are missing** — misleading status code for a configuration problem.
9. **No endpoint for "books currently out for one book"** — derive it from `unreturned/all`.
10. **No summary or stats endpoint** — the dashboard derives all four of its counts client-side from four separate list calls.
