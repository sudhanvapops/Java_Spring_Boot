# 02 · Pages Required

Every route in the app, what it's for, what it shows in each state, and what the words say.

---

## Route map

```
app/
├── (auth)/                        ← public, centered card, no chrome
│   ├── login
│   ├── signup
│   ├── forgot-password
│   ├── reset-password             ← ?token=…
│   └── verify-email               ← ?token=…   (optional)
│
├── (app)/                         ← protected, sidebar + topbar
│   ├── dashboard
│   ├── books
│   │   ├── new
│   │   └── [id]
│   │       └── edit
│   ├── members
│   │   ├── new
│   │   └── [id]
│   │       └── edit
│   ├── lend                       ← borrow flow
│   ├── returns                    ← return flow
│   ├── transactions
│   │   └── [id]
│   ├── records
│   │   ├── unreturned
│   │   └── due-today
│   └── settings
│       ├── library
│       └── account
│
├── not-found
└── error
```

**23 routes.** 5 auth, 16 application, 2 system.

---

## Summary table

| Route | Page | Auth | Primary endpoints |
|-------|------|------|-------------------|
| `/login` | Log in | Public | `POST /api/auth/login` **PROPOSED** |
| `/signup` | Create account | Public | `POST /api/auth/signup` **PROPOSED** |
| `/forgot-password` | Request reset link | Public | `POST /api/auth/forgot-password` **PROPOSED** |
| `/reset-password` | Set new password | Token | `POST /api/auth/reset-password` **PROPOSED** |
| `/verify-email` | Confirm email | Token | `POST /api/auth/verify-email` **PROPOSED** |
| `/dashboard` | Today at a glance | Librarian | `GET /api/borrowrecord/due-today`, `/api/book`, `/api/member`, `/api/borrowrecord/unreturned/all` |
| `/books` | Catalogue | Librarian | `GET /api/book`, `/api/book/name`, `/api/book/author` |
| `/books/new` | Add book | Librarian | `POST /api/book` |
| `/books/[id]` | Book detail | Librarian | `GET /api/book/id/{id}` |
| `/books/[id]/edit` | Edit book | Librarian | `GET /api/book/id/{id}`, `PUT /api/book/{id}` |
| `/members` | Members | Librarian | `GET /api/member` |
| `/members/new` | Register member | Librarian | `POST /api/member` |
| `/members/[id]` | Member detail | Librarian | `GET /api/member/{id}`, `/api/borrowrecord/unreturned/{memberId}`, `/api/borrow-transactions/member-id/{memberId}` |
| `/members/[id]/edit` | Edit member | Librarian | `GET /api/member/{id}`, `PUT /api/member/{id}` |
| `/lend` | Lend books | Librarian | `GET /api/member`, `/api/book`, `POST /api/borrow-transactions/borrow` |
| `/returns` | Take books back | Librarian | `GET /api/borrowrecord/unreturned/{memberId}`, `POST /api/borrowrecord/return` |
| `/transactions` | All transactions | Librarian | `GET /api/borrow-transactions/all` |
| `/transactions/[id]` | Transaction detail | Librarian | `GET /api/borrow-transactions/{id}` |
| `/records` | All borrow records | Librarian | `GET /api/borrowrecord/all` |
| `/records/unreturned` | Currently out | Librarian | `GET /api/borrowrecord/unreturned/all` |
| `/records/due-today` | Due today | Librarian | `GET /api/borrowrecord/due-today` |
| `/settings/library` | Library rules | Librarian | `GET /api/settings/all`, `POST`/`PUT`/`DELETE /api/settings` |
| `/settings/account` | My account | Any signed in | `GET /api/auth/me`, `POST /api/auth/change-password` **PROPOSED** |

---

## Shared patterns

Defined once here, referenced by every page below.

### The four states

Every screen that loads data has four. Design all four or the screen is unfinished.

| State | Treatment |
|-------|-----------|
| **Loading** | Skeleton rows on `surface-1` at `rounded.md`. Never a centred spinner on a full page — it hides the layout. |
| **Empty** | Centred in the content area: a short headline, one line of explanation, one primary action. An empty screen is an invitation to act. |
| **Error** | Inline panel on `surface-1` with a `hairline-strong` border and a `semantic-danger` icon. States what failed and offers **Try again**. Never a bare error code. |
| **Loaded** | The real thing. |

### List page pattern

Used by `/books`, `/members`, `/transactions`, `/records`, `/records/unreturned`, `/records/due-today`.

```
┌────────────────────────────────────────────────────────┐
│  Page title                              [Primary CTA] │  ← headline / button-primary
│  One line of context                                   │  ← body-sm, ink-subtle
├────────────────────────────────────────────────────────┤
│  [ Search…        ]   [ Filter ▾ ]   [ 128 results ]   │  ← text-input, tab row, caption
├────────────────────────────────────────────────────────┤
│  Column   Column   Column   Column            Actions  │  ← caption, ink-subtle, uppercase-ish
│  ──────────────────────────────────────────────────────│  ← hairline
│  Row                                                   │
│  Row                                                   │
└────────────────────────────────────────────────────────┘
```

Rules:
- Table sits directly on `canvas` with `hairline` row dividers — not inside a card. Cards around tables waste horizontal space.
- Row hover: `surface-1`. Row click: navigate to detail. Actions column: icon buttons, revealed on hover but always keyboard-reachable.
- Header row is sticky.
- Search is client-side and instant for `/members`, `/transactions`, `/records`. For `/books`, see the note under `/books` below.
- Result count sits next to the filters as a `caption`, always visible. It's the fastest way to confirm a filter did something.
- Sorting: click a column header. Sort state must be visible in the header, not just implied by the data.

### Form page pattern

Used by `/books/new`, `/books/[id]/edit`, `/members/new`, `/members/[id]/edit`.

```
┌─────────────────────────────────┐
│  ← Back to books                │  ← body-sm, ink-subtle
│                                 │
│  Add a book                     │  ← headline
│  One line explaining the form    │  ← body-sm, ink-subtle
│                                 │
│  ┌─── surface-1, rounded.lg ──┐ │
│  │  Label                      │ │  ← body-sm, ink-muted
│  │  [ input                  ] │ │  ← text-input
│  │  Helper text                │ │  ← caption, ink-subtle
│  │                             │ │
│  │  …more fields               │ │
│  └─────────────────────────────┘ │
│                                 │
│  [Save book]  [Cancel]          │  ← button-primary / button-tertiary
└─────────────────────────────────┘
```

Rules:
- Max width 560px. Single column. Multi-column forms slow people down on short forms.
- Labels above fields, always visible. No placeholder-only inputs.
- Validate on blur, then on every change once a field has errored. Never validate on first keystroke.
- Error message below the field, `semantic-danger`, with an icon. Never colour alone.
- Submit disabled only while submitting — not while invalid. A disabled submit button hides *why* it's disabled.
- On submit failure, focus the first errored field and announce the count to screen readers.
- Buttons are named for what they do: **Save book**, **Register member**, **Lend 3 books**. Never "Submit".

### Confirmation dialogs

Required for: deactivate book, deactivate member, delete setting.

Structure: what will happen, what it affects, what it doesn't. Primary button uses `semantic-danger` background and states the action — **Deactivate book**, not "Confirm". Cancel is `button-tertiary`.

Always say the thing is reversible when it is. Deactivation is a soft delete and reactivation exists — say so, and people will stop hesitating.

---

## Application shell

Wraps every route in `(app)`.

**Sidebar** — 240px, `canvas` background, `hairline` right border. Collapses to icon-only below 1024px, becomes a sheet below 768px.

```
Stacks                          ← wordmark, card-title

  Overview                      ← /dashboard
  ─────────────
  CATALOGUE                     ← eyebrow, ink-tertiary
  Books                         ← /books
  Members                       ← /members
  ─────────────
  CIRCULATION                   ← eyebrow
  Lend                          ← /lend
  Returns                       ← /returns
  Due today            ⚠ 4      ← /records/due-today, count badge
  Currently out                 ← /records/unreturned
  ─────────────
  HISTORY                       ← eyebrow
  Transactions                  ← /transactions
  Records                       ← /records
  ─────────────
  Settings                      ← /settings/library

  ┌──────────────────────┐
  │ ◐  Priya Nair        │      ← account menu, pinned bottom
  │    Librarian         │
  └──────────────────────┘
```

Active item: `surface-2` background, `rounded.md`, `ink` text, and a 2px `primary` left bar. The bar is what makes it unambiguous at a glance.

Sidebar groups are not decoration — they mirror how the day actually splits: what you own (catalogue), what's moving (circulation), what happened (history).

**Topbar** — 56px, `canvas`, `hairline` bottom border. Breadcrumb on the left, global search (`⌘K`) and account menu on the right. On mobile, the hamburger replaces the breadcrumb.

**Account menu**: My account · Keyboard shortcuts · Log out.

---

## Auth pages

All five share one layout. This is where the stack's animated components earn their place — everywhere else they'd be noise.

```
┌───────────────────────────────────────────────┐
│                                               │
│   [ambient background effect, very low key]   │
│                                               │
│        ┌─────────────────────────┐            │
│        │  Stacks                 │            │  ← wordmark
│        │                         │            │
│        │  Welcome back           │            │  ← display-md
│        │  Sign in to the console │            │  ← body, ink-subtle
│        │                         │            │
│        │  Email                  │            │
│        │  [                    ] │            │
│        │  Password        Forgot?│            │
│        │  [                  👁 ] │            │
│        │                         │            │
│        │  [    Sign in         ] │            │  ← full width
│        │                         │            │
│        │  New here? Create one   │            │
│        └─────────────────────────┘            │
│                                               │
└───────────────────────────────────────────────┘
```

Card: 420px wide, `surface-1`, `rounded.xl`, `hairline` border, 32px padding, vertically centred. Background effect at very low opacity — it should be felt, not seen. See `10-ui-components.md`.

---

### `/login` — Log in

**Fields:** Email, Password (with a show/hide toggle), "Keep me signed in" checkbox.

**Copy:**
- Title: `Welcome back`
- Subtitle: `Sign in to the library console.`
- Button: `Sign in` → while pending: `Signing in…`
- Links: `Forgot password?` (inline, right of the password label) · `New here? Create an account`

**States:**

| State | Behaviour |
|-------|-----------|
| Invalid credentials | One message above the form: `That email and password don't match.` Never say which one is wrong. |
| Account inactive | `This account has been deactivated. Ask an administrator to restore it.` |
| Email unverified | `Confirm your email first.` + a `Resend the link` action. |
| Rate limited | `Too many attempts. Try again in 5 minutes.` Disable submit and count down. |
| Network down | `Can't reach the server.` + `Try again`. |
| Success | Redirect to `?next=` if present and internal, otherwise `/dashboard`. |

**Behaviour:** email autofocused on mount; Enter submits from either field; browser password managers must work (correct `autocomplete` attributes, real form semantics).

---

### `/signup` — Create account

**Fields:** Full name, Email, Password, Confirm password. Terms checkbox if you have terms.

**Copy:**
- Title: `Create your account`
- Subtitle: `Set up access to the library console.`
- Button: `Create account`
- Link: `Already have an account? Sign in`

**Password strength meter:** a 4-segment bar under the field using `hairline` → `semantic-danger` → `semantic-warning` → `semantic-success`, with a text label beside it (`Weak` / `Fair` / `Strong`). Colour alone is not enough. Requirements are listed as a checklist that ticks off live — people fix passwords faster when they can see what's missing.

**States:**

| State | Behaviour |
|-------|-----------|
| Email taken | Inline on the email field: `That email already has an account.` + `Sign in instead` link. |
| Weak password | Blocks submit; the checklist shows exactly which rule failed. |
| Mismatch | On the confirm field: `Passwords don't match.` |
| Success (verification on) | Route to a confirmation view: `Check your email — we sent a confirmation link to priya@…` + `Resend` (60s cooldown). |
| Success (verification off) | Auto sign-in and redirect to `/dashboard`. |

**Depends on DECISION 1** in `01-project-overview.md`. If signup is invite-only, this page becomes a token-gated form and the "create an account" links disappear from `/login`.

---

### `/forgot-password` — Request a reset link

**Field:** Email only.

**Copy:**
- Title: `Reset your password`
- Subtitle: `We'll email you a link to set a new one.`
- Button: `Send reset link`
- Link: `Back to sign in`

**Critical:** the success message is identical whether or not the email exists. Anything else is an account-enumeration hole.

> **Check your inbox**
> If an account exists for priya@example.com, a reset link is on its way. The link expires in 30 minutes.
> Didn't get it? *Send again* (enabled after 60 seconds)

---

### `/reset-password` — Set a new password

Reached from the emailed link: `/reset-password?token=…`

**Fields:** New password, Confirm new password. Same strength meter as signup.

**Validate the token on mount**, before showing the form. Showing a form that's already dead is a small cruelty.

| Token state | Screen |
|-------------|--------|
| Valid | The form. |
| Expired | `This link has expired.` / `Reset links last 30 minutes.` / **Request a new link** |
| Already used | `This link has already been used.` / **Request a new link** |
| Malformed / missing | `This reset link isn't valid.` / **Request a new link** |

**On success:** invalidate all existing sessions, then show `Password updated. Sign in with your new password.` and route to `/login`. Do not auto sign-in — if the reset was triggered by someone else, auto sign-in hands them the session.

---

### `/verify-email` — Confirm email *(optional)*

No form. Reads `?token=`, calls the endpoint, shows one of three results.

| Result | Screen |
|--------|--------|
| Verifying | Centred spinner + `Confirming your email…` |
| Success | `Email confirmed` + **Go to the console** |
| Expired / invalid | `This link has expired.` + **Send a new one** (email input, since the user may not be signed in) |

---

## `/dashboard` — Today at a glance

The first screen after sign-in. It answers one question: **what needs doing right now?**

Resist the four-stat-cards-and-a-chart reflex. The API has no time series to chart, and fake charts are worse than none.

```
Good morning, Priya                              Tue 4 Aug
Four books are due back today.

┌──────────────┬──────────────┬──────────────┬──────────────┐
│ Out on loan  │ Due today    │ Overdue      │ Active members│
│ 47           │ 4            │ 2            │ 128          │
└──────────────┴──────────────┴──────────────┴──────────────┘

┌── Due back today ──────────────────────── [View all →] ──┐
│  The Pragmatic Programmer   Hunt & Thomas                │
│  Priya Nair · priya@…                    [Take it back]  │
│  ────────────────────────────────────────────────────────│
│  …3 more                                                 │
└──────────────────────────────────────────────────────────┘

┌── Quick actions ─────────────────────────────────────────┐
│  [Lend books]  [Take books back]  [Add a book]           │
└──────────────────────────────────────────────────────────┘
```

**Stat cards:** `dashboard-card`, `surface-1`, `rounded.xl`. Number in Geist Sans at `display-md`, label in `caption` / `ink-subtle` above it. Overdue count switches to `semantic-danger` *and* gains a warning icon when above zero.

**Data sources:** the API has no summary endpoint, so counts are derived client-side.

| Stat | Derived from |
|------|--------------|
| Out on loan | `GET /api/borrowrecord/unreturned/all` → length |
| Due today | `GET /api/borrowrecord/due-today` → length |
| Overdue | `unreturned/all` filtered to `dueDate < today` |
| Active members | `GET /api/member` filtered to `isActive` |

That's four requests on load, all unpaginated. Fire them in parallel, cache for 60 seconds, and let each stat card resolve independently — one slow response shouldn't hold the others hostage.

**Empty state (nothing due, nothing out):** `Nothing due today.` / `The shelves are quiet. 47 books are out on loan and none are due back yet.` — no primary CTA needed; the quick actions are already on screen.

**Greeting** changes with the hour (Good morning / afternoon / evening). Small touch, and it makes the console feel like it knows what time it is.

---

## Books

### `/books` — Catalogue

List page pattern. **Primary CTA:** `Add a book`.

**Columns:** Title · Author · Available / Total · Status · Actions

- Availability renders as `3 / 5` with a thin proportional bar beneath. At `0 / 5` the number turns `semantic-danger` and reads `None available`.
- Status is a `status-badge`: `Active` (`ink-muted` on `surface-2`) or `Inactive` (`ink-tertiary`, plus a dot).
- Actions: View · Edit · Deactivate (or Reactivate).

**Filters:** `All` · `Available` · `Unavailable` · `Inactive` — as a `tab-default` / `tab-selected` row.

**Search — important:** there are three ways to get books and they behave differently.

| Approach | Endpoint | Trade-off |
|----------|----------|-----------|
| Client-side filter (recommended) | `GET /api/book` once | Instant, searches title *and* author at once, works offline of the server. Only viable while the catalogue is small. |
| Server search by title | `GET /api/book/name?name=…` | Returns `404` when nothing matches — treat as empty, not error. |
| Server search by author | `GET /api/book/author?author=…` | Same. Requires the user to choose a field first. |

Recommendation: **fetch once, filter client-side.** One input, no mode switcher, no 404 handling. Revisit past ~2,000 books.

**Empty (no books at all):** `No books yet` / `Add the first title to your catalogue.` / **Add a book**
**Empty (search found nothing):** `No books match "gibbon"` / `Try a different title or author.` / **Clear search**

Those are different situations and must not share a screen.

### `/books/new` — Add a book

Form page pattern. Fields: Title, Author, Total copies.

**Do not show `availableCopies` on this form.** The API requires it, but on a brand new book it is always equal to total copies. Send it silently. Asking a librarian to enter the same number twice is how you get data entry bugs.

**Do not show `isActive` either.** Send `true`.

- Total copies: number input with stepper, min 1, default 1. Helper: `How many physical copies the library owns.`
- Button: `Add book` → on success, toast `"The Pragmatic Programmer" added.` and route to `/books/[id]`.
- Conflict (`409 BOOK_ALREADY_EXISTS`): inline error across both title and author — `A book with this title and author already exists.` + a link to the existing record.

### `/books/[id]` — Book detail

```
← Back to books

The Pragmatic Programmer                    [Edit] [Deactivate]
Andrew Hunt, David Thomas
[Active]  ·  ID 42                                    ← mono for the ID

┌── Copies ─────────────┐  ┌── Currently out ──────────────────┐
│  3 available          │  │  Priya Nair    due 11 Aug         │
│  of 5 total           │  │  Arjun Rao     due 09 Aug  ⚠ over │
│  ▓▓▓░░                │  └───────────────────────────────────┘
└───────────────────────┘
```

The "currently out" panel is derived: fetch `GET /api/borrowrecord/unreturned/all` and filter to this `borrowedBookId`. There is no per-book endpoint. If the dataset is large this is wasteful — cache it, since `/dashboard` needs the same call.

**Inactive book:** the whole header gets an inactive treatment (`ink-subtle` title, `Inactive` badge) and a banner: `This book is inactive and can't be lent.` + **Reactivate**.

### `/books/[id]/edit` — Edit book

Form page pattern, prefilled. Here `availableCopies` **is** shown, because it can legitimately drift from total, but it's read-only with an explanation: `3 available of 5 · adjusted automatically when books are lent and returned.`

Total copies is editable. If it's lowered below the number currently on loan, warn before saving — the backend may reject it (`INVALID_BOOK_COPIES`).

**Deactivate** lives here as a destructive action at the bottom of the form, separated by a `hairline` divider, not in the main flow.

> **Deactivate this book?**
> It stays in the catalogue and its history is kept, but it can't be lent until you reactivate it.
> Books currently on loan must be returned first.
> [Deactivate book] [Cancel]

---

## Members

### `/members` — Members

List page pattern. **Primary CTA:** `Register a member`.

**Columns:** Name · Email · Age · Books out · Status · Actions

"Books out" is derived from `unreturned/all` grouped by `memberId`. Worth it — it's the number a librarian actually wants when scanning the list.

**Filters:** `All` · `Active` · `Inactive` · `Has books out`
**Search:** client-side across name and email.

**Empty:** `No members yet` / `Register your first member to start lending.` / **Register a member**

### `/members/new` — Register a member

Fields: Full name, Email, Age. `isActive` sent as `true`, not shown.

- Age: number, min 1. Helper: `Used for age-restricted titles.` — if you have no age restrictions, say `Required by the library record system.` Don't leave a bare number field unexplained.
- Conflict (`409 MEMBER_EMAIL_ALREADY_EXISTS`): inline on email — `That email is already registered.` + link to the existing member.
- On success: toast + route to `/members/[id]`.

### `/members/[id]` — Member detail

The busiest read-only screen in the app. A librarian lands here mid-conversation with a person at the desk.

```
← Back to members

Priya Nair                            [Lend books] [Edit]
priya@example.com · 34 · [Active] · ID 17

┌── Out now (2) ───────────────────────────────────────────┐
│  The Pragmatic Programmer   due 11 Aug                   │
│  Designing Data-Intensive…  due 09 Aug   ⚠ 3 days over   │
│                                        [Take books back] │
└──────────────────────────────────────────────────────────┘

┌── History ───────────────────────────────────────────────┐
│  [Transactions] [All records]              ← tab row     │
│  …                                                        │
└──────────────────────────────────────────────────────────┘
```

Three parallel requests: the member, `unreturned/{memberId}`, and `borrow-transactions/member-id/{memberId}`. Both of the latter return `404` when the member simply has no history — render an empty panel, not an error.

**Overdue rows:** `semantic-danger` text, a warning icon, and the day count spelled out. Never rely on red alone.

**Inactive member:** banner — `This member is deactivated and can't borrow books.` + **Reactivate**.

### `/members/[id]/edit` — Edit member

Standard form. Deactivate at the bottom.

> **Deactivate this member?**
> Their record and history are kept. They won't be able to borrow until reactivated.
> Members with books still out can't be deactivated — take those back first.

If the API returns `409 MEMBER_HAS_ACTIVE_BORROWS`, surface it as: `Priya still has 2 books out. Take them back before deactivating.` + **Go to returns**.

---

## Circulation

These two screens are the reason the app exists. Everything else is upkeep.

### `/lend` — Lend books

A two-panel workspace, not a form. Optimise for a librarian standing at a desk with a stack of books.

```
Lend books
Pick a member, add their books, then confirm.

┌── 1 · Member ──────────────┐  ┌── 2 · Books ──────────────────┐
│  [ Search members…      ]  │  │  [ Search the catalogue…    ] │
│                            │  │                               │
│  ◐ Priya Nair              │  │  The Pragmatic Programmer     │
│    priya@example.com       │  │  Hunt & Thomas · 3 available  │
│    2 out · 3 more allowed  │  │                        [Add]  │
│                  [Change]  │  │  ───────────────────────────  │
└────────────────────────────┘  │  Clean Code                   │
                                │  Martin · none available  ✕   │
┌── 3 · Confirm ─────────────┐  └───────────────────────────────┘
│  2 books · due 18 Aug      │
│  • The Pragmatic Programmer│
│  • Refactoring             │
│                            │
│  [ Lend 2 books ]          │
└────────────────────────────┘
```

**Step 1 — member.** Search, then select. Once selected, the panel collapses to a summary showing the two facts that matter: how many they already have out, and how many more they're allowed. That second number comes from `MAX_BOOKS` in settings minus current unreturned. Showing it up front prevents a failed submit at the end.

**Step 2 — books.** Search the catalogue. Each row shows availability. Unavailable and inactive books are visible but not addable, with the reason stated (`None available`, `Inactive`). Hiding them makes librarians think the search is broken.

**Guard rails — enforce client-side before submitting:**

| Rule | Message |
|------|---------|
| No duplicate books in one basket | `Already in this basket.` — disable the Add button on that row |
| Member already has this title out | `Priya already has this book.` — from `unreturned/{memberId}` |
| Would exceed `MAX_BOOKS` | `That's over Priya's limit of 5 books. Remove one first.` — block Add |
| Book has no copies left | `No copies available.` — Add disabled |
| Member inactive | Block at step 1: `This member is deactivated and can't borrow.` |

Every one of these maps to a backend error the API will throw anyway. Catching them in the UI turns a failed round-trip into an inline hint.

**Step 3 — confirm.** Shows the basket, the count, and the computed due date (today + `MAX_BORROW_DAYS`). Button reads `Lend 2 books` — the count in the label is a last-chance check against the physical stack on the desk.

**On success:** a receipt view — member, books, due date, transaction ID in mono — with `Print` and `Lend more books`. Do not silently redirect. The librarian may need to write the due date on a slip.

**Settings dependency:** if `MAX_BOOKS` or `MAX_BORROW_DAYS` isn't configured, the backend returns `404`. Check settings on mount and, if missing, block the screen with: `Library rules aren't set up yet. Set the borrowing limits before lending books.` + **Go to settings**.

### `/returns` — Take books back

```
Take books back
Find the member, tick what they've brought in.

┌── Member ─────────────────────────────────────────────────┐
│  [ Search members…                                      ]  │
│  ◐ Priya Nair · 2 books out                     [Change]  │
└───────────────────────────────────────────────────────────┘

┌── Out now ────────────────────────────────────────────────┐
│  ☑ The Pragmatic Programmer   due 11 Aug        no fine   │
│  ☑ Designing Data-Intensive…  due 09 Aug  ⚠ 3 days · ₹30  │
│  ☐ Refactoring                due 20 Aug        no fine   │
└───────────────────────────────────────────────────────────┘

┌── Total ──────────────────────────────────────────────────┐
│  2 books · fine due  ₹30                                  │
│  Returning today, 4 Aug            [Change date]           │
│  [ Take back 2 books ]                                     │
└───────────────────────────────────────────────────────────┘
```

**Fine preview is calculated client-side** — `days overdue × FINE_PER_DAY` — and clearly labelled as an estimate until the server confirms. The backend is the source of truth; `BookReturnResponse` carries the real per-book `fine` and `totalFine`. If they differ, show the server figure and quietly correct.

**Return date** defaults to now and is editable for backdating (a book found in the drop box yesterday). Future dates are rejected by the backend (`INVALID_RETURN_DATE`) — block them in the picker rather than letting the request fail.

**Select all** checkbox in the panel header. Most returns are "everything they're carrying."

**On success:** receipt showing each book, its fine, and the total. If a fine is owed, say so plainly: `₹30 to collect.` The app doesn't process payment — it tells the librarian what to ask for.

**Empty:** member selected but nothing out → `Priya has no books out.` / `Nothing to take back.`

---

## History

### `/transactions` — Transactions

List page pattern, read-only. A transaction is one lending event, possibly covering several books.

**Columns:** ID (mono) · Member · Books · Borrowed on

"Books" shows a count with the first title and `+2 more`. Row click → detail.

**Note:** `BorrowTransactionResponse` nests full book details in `books[]`, so the list endpoint returns a lot of data. Another reason to cache aggressively.

### `/transactions/[id]` — Transaction detail

Header with transaction ID (mono), member name, and borrow date. Below it, each book as a row: title, author, due date, and — derived from `unreturned/all` — whether it's still out or has come back.

### `/records` — Borrow records

Every individual book-loan row, across all members and transactions. This is the raw ledger.

**Columns:** Book · Author · Member · Due date · Status

**Filters:** `All` · `Out` · `Returned` · `Overdue`

Sort by due date descending by default — the useful end of the list is the recent end.

### `/records/unreturned` — Currently out

Same table, pre-filtered to books not yet returned. Sorted by due date **ascending** so the most urgent sits at the top. Overdue rows get `semantic-danger` treatment and a day count.

### `/records/due-today` — Due today

The one screen designed to be acted on rather than read. Uses `DueTodayResponse`, which uniquely includes `memberEmail` — the only endpoint that does.

**Columns:** Book · Member · Email · Actions (`Take it back`)

Because the email is here, a `Copy all emails` action at the top of the list is genuinely useful for sending reminders. Small feature, disproportionate payoff.

**Empty:** `Nothing due today` / `No books need to come back today.` — this endpoint returns `200` with an empty list, not a 404. It's the well-behaved one.

---

## Settings

### `/settings/library` — Library rules

Not a generic key-value editor. There are exactly **three** settings, fixed by the backend enum. Design for three known things.

```
Library rules
These control how lending works across the whole library.

┌── Books per member ──────────────────────────────────────┐
│  How many books one member can have out at a time.       │
│  [ 5        ]  books                          [Save]     │
└──────────────────────────────────────────────────────────┘

┌── Loan length ───────────────────────────────────────────┐
│  How long a member can keep a book.                      │
│  [ 14       ]  days                           [Save]     │
└──────────────────────────────────────────────────────────┘

┌── Late fee ──────────────────────────────────────────────┐
│  Charged for each day a book is overdue.                 │
│  ₹ [ 10.00  ]  per day                        [Save]     │
└──────────────────────────────────────────────────────────┘
```

**The create/update trap.** `POST /api/settings` fails if the key exists; `PUT /api/settings` fails if it doesn't. So:

1. On mount, `GET /api/settings/all`.
2. For each of the three keys, note whether it came back.
3. A card whose setting exists → **Save** uses `PUT`.
4. A card whose setting is missing → shows as unconfigured, and **Save** uses `POST` with the correct `valueType` (`INTEGER` for `MAX_BOOKS` and `MAX_BORROW_DAYS`, `DECIMAL` for `FINE_PER_DAY`).

**Unconfigured card:** `hairline-strong` border, `semantic-warning` icon, and `Not set yet — lending is blocked until you set this.` Because it genuinely is.

Each card saves independently with its own state. One shared Save button for three unrelated rules is a worse experience and a worse failure mode.

**A warning worth showing:** these values are applied at the moment of lending, so changing the loan length doesn't move existing due dates. Say so under the loan length card in `caption` / `ink-subtle`. People assume otherwise.

**Delete** is available per setting but should be tucked away — a destructive action that breaks lending. Put it behind an overflow menu on the card, never a visible button.

### `/settings/account` — My account

Two sections on one page.

**Profile** — name and email, read-only in Phase 1 (no endpoint to change them). Show the role as a `status-badge`.

**Password** — current password, new password, confirm. Same strength meter as signup. On success: `Password updated.` and, if you invalidate other sessions server-side, `You've been signed out everywhere else.`

**Sign out** at the bottom, `button-secondary`.

---

## System pages

### `not-found`

`Page not found` / `That page doesn't exist, or it moved.` / **Back to the console**. Keep the app shell if the user is signed in — dropping someone out of the app for a bad URL is disorienting.

### `error`

`Something went wrong` / `The console hit an unexpected error. Trying again usually works.` / **Try again** + **Back to overview**. Show the error reference in mono at `caption` size, `ink-tertiary` — useful when he's debugging, invisible to everyone else.

---

## Phase 2 — Member portal

Specced only. Requires the `memberId` link from **DECISION 2** and backend scoping so members can only see their own data.

| Route | Purpose |
|-------|---------|
| `/my/books` | What I have out, with due dates and running fines |
| `/my/history` | Everything I've borrowed |
| `/catalogue` | Browse and search books, read-only, no lending actions |
| `/my/account` | Profile and password |

The member-facing app should reuse every component but drop the sidebar to a simple top nav — members have four destinations, not twelve.
