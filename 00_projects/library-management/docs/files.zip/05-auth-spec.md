# 05 · Auth Spec

Signup, login, and password reset. **None of this exists in the backend yet** — everything here is PROPOSED and needs Spring Boot work before the frontend can function.

---

## What's missing today

`v3.json` has no auth of any kind: no login, no tokens, no roles, no security schemes, no `401` or `403` on any endpoint. All 30 endpoints are open.

`POST /api/member` is labelled "Register a new member" but takes `{ name, email, age, isActive }` — no password, no credentials. It creates a library record, not an account.

**Two separate concepts** that must stay visually separate in the UI:

| | Account | Member |
|---|---------|--------|
| What | Someone who signs in | Someone who borrows books |
| Has a password | Yes | No |
| Exists today | No | Yes |
| Created at | `/signup` | `/members/new` |

A librarian has an account and is not a member. A member has no account in Phase 1. `DECISION 2` (a nullable `memberId` on the account) is what eventually lets one person be both.

---

## Token strategy

**Recommended: access token in memory, refresh token in an httpOnly cookie.**

| Token | Lifetime | Stored | Sent as |
|-------|----------|--------|---------|
| Access | ~15 min | Zustand, **not persisted** | `Authorization: Bearer …` |
| Refresh | ~7 days | httpOnly + Secure + SameSite cookie | Automatically by the browser |

**Why not localStorage.** Anything in localStorage is readable by any script on the page. One compromised dependency — and a Next.js app has hundreds — and the token walks. An httpOnly cookie can't be read by JavaScript at all.

**Why the access token lives in memory.** It vanishes on refresh, which sounds like a bug and isn't: on mount, the app calls `/api/auth/refresh`, the browser sends the cookie automatically, and a new access token comes back. The user stays signed in without a long-lived credential ever touching disk.

**The cost:** a brief loading state on every full page load while the refresh happens. Budget for it in the app shell — a skeleton, not a spinner, and never a flash of the login screen.

**CORS requirement.** The API is on a different origin (`localhost:8080` vs `localhost:3000`). For cookies to work, the backend must set `Access-Control-Allow-Credentials: true` and name the exact frontend origin — `*` is not allowed alongside credentials. Axios needs `withCredentials: true`. This is the single most common place this setup breaks.

### Simpler fallback

If refresh-token infrastructure is more than this project needs: one long-lived (24h) access token in `sessionStorage`, no refresh endpoint. It's weaker — a stolen token is valid for a day and XSS can read it — but it's honest, small, and fine for a local practice project. **Do not ship it anywhere real.** If you take this path, write down why, so future-you knows it was a choice.

---

## Proposed endpoints

### `POST /api/auth/signup`

```json
{ "name": "Priya Nair", "email": "priya@example.com", "password": "…" }
```

| Code | Meaning |
|------|---------|
| `201` | Created. Returns `AuthResponse` (auto sign-in) or a "check your email" acknowledgement if verification is on |
| `400` | `PASSWORD_TOO_WEAK` or validation failure |
| `409` | `ACCOUNT_ALREADY_EXISTS` |

Server-side: lowercase and trim the email, hash with BCrypt (cost ≥ 10), never echo the password back in any form.

---

### `POST /api/auth/login`

```json
{ "email": "priya@example.com", "password": "…" }
```

**`200`** → `AuthResponse` in the body, refresh token as a `Set-Cookie` header.

```json
{
  "accessToken": "eyJhbGciOi…",
  "expiresIn": 900,
  "user": { "id": 1, "name": "Priya Nair", "email": "priya@example.com", "role": "LIBRARIAN", "memberId": null }
}
```

| Code | Meaning |
|------|---------|
| `401` | `INVALID_CREDENTIALS` — **same response for wrong password and unknown email** |
| `403` | `ACCOUNT_INACTIVE` or `EMAIL_NOT_VERIFIED` |
| `429` | `RATE_LIMIT_EXCEEDED` |

The identical-response rule matters: distinguishing "no such user" from "wrong password" hands an attacker a list of valid emails. Same message, same status, and ideally the same response time.

---

### `POST /api/auth/refresh`

No body. The browser sends the refresh cookie. Returns a fresh `AuthResponse`.

`401` → refresh token missing, expired, or revoked. The client must clear auth state and redirect to `/login`.

**Rotate on every refresh** — issue a new refresh token and invalidate the old one. If a rotated token is ever reused, that's a signal it was stolen: revoke the whole family and force a re-login.

---

### `POST /api/auth/logout`

Invalidates the refresh token server-side and clears the cookie. Requires the bearer token.

Always returns `200`, even if the token was already dead. Logout failing is a worse experience than logout being idempotent.

---

### `GET /api/auth/me`

Returns the current account. Used to rehydrate state after a refresh and to check that a token is still good.

---

### `POST /api/auth/forgot-password`

```json
{ "email": "priya@example.com" }
```

**Always returns `200`,** whether or not the account exists. Same body, same timing. This is the whole point of the endpoint's design.

Server-side: generate a ≥ 32-byte random token, store a *hash* of it (not the token itself), set a 30-minute expiry, invalidate any earlier unused tokens for that account, and email the link. Rate limit per email and per IP.

---

### `POST /api/auth/reset-password`

```json
{ "token": "…", "password": "…" }
```

| Code | Meaning |
|------|---------|
| `200` | Password changed |
| `400` | `PASSWORD_TOO_WEAK` |
| `401` | `TOKEN_INVALID` · `TOKEN_EXPIRED` · `TOKEN_ALREADY_USED` |

Distinguish the three token failures in the `errorCode` — each one gets a different screen, and none of them leaks anything useful to an attacker who doesn't already hold the token.

On success: mark the token used, **revoke every refresh token for the account**, and do *not* sign the user in. If the reset was triggered by an attacker who intercepted the email, auto sign-in hands them the session.

**Also worth adding:** `GET /api/auth/reset-password/validate?token=…` returning `200` or `401`. Lets `/reset-password` check the token on mount and show the expiry screen before rendering a form that can't work.

---

### `POST /api/auth/change-password`

```json
{ "currentPassword": "…", "newPassword": "…" }
```

Bearer required. `401` if the current password is wrong. Revoke other sessions on success and tell the user you did.

---

### `POST /api/auth/verify-email` · `POST /api/auth/resend-verification`

Optional, gated on whether email verification is switched on. Same token rules as password reset. Resend must be rate limited hard — it's an email-sending endpoint that takes an arbitrary address.

---

## Flows

### Signup

```
/signup  →  validate (zod, client)
         →  POST /api/auth/signup
         │
         ├─ 409 → inline on email + "Sign in instead"
         ├─ 400 → password checklist shows what failed
         │
         ├─ 201, verification OFF
         │    → store access token in memory, user in zustand
         │    → redirect /dashboard
         │
         └─ 201, verification ON
              → "Check your email" screen, resend on 60s cooldown
              → user clicks link → /verify-email?token=…
              → POST /api/auth/verify-email → redirect /login
```

### Login

```
/login   →  validate
         →  POST /api/auth/login   (withCredentials)
         │
         ├─ 401 → "That email and password don't match."
         ├─ 403 → inactive, or unverified + resend action
         ├─ 429 → countdown, submit disabled
         │
         └─ 200 → access token → memory
                  user → zustand
                  redirect to ?next= (internal only) or /dashboard
```

**Guard the `next` param.** Only accept paths starting with a single `/`. An open redirect on a login page is a phishing primitive.

### Password reset

```
/forgot-password → POST /api/auth/forgot-password → always 200
                 → "If an account exists…" (identical either way)

email link → /reset-password?token=…
           → validate token on mount
           │
           ├─ invalid/expired/used → dedicated screen + "Request a new link"
           │
           └─ valid → form → POST /api/auth/reset-password
                    → 200 → revoke all sessions
                          → "Password updated. Sign in with your new password."
                          → /login   (no auto sign-in)
```

### Session lifecycle

```
App loads
   → POST /api/auth/refresh
   │
   ├─ 200 → access token to memory, user to state → render app
   └─ 401 → clear state → /login?next=<current path>

During use
   → any 401 from any endpoint
       → pause the request
       → refresh once
       ├─ success → replay the original request
       └─ failure → clear state → /login

Idle
   → refresh proactively at ~80% of token lifetime (≈12 min for a 15 min token)
```

**Queue concurrent 401s.** Three requests failing at once must trigger *one* refresh, not three. The interceptor pattern for this is in `08-api-client.md`.

---

## Route protection

| Group | Routes | Rule |
|-------|--------|------|
| Public | `/login`, `/signup`, `/forgot-password`, `/reset-password`, `/verify-email` | Signed-in users are bounced to `/dashboard` |
| Protected | Everything in `(app)` | No session → `/login?next=…` |
| Role-gated | `/settings/library`, member management | `LIBRARIAN` only |

**Three layers, and all three are needed:**

1. **Middleware** — checks the refresh cookie's presence and redirects early. Fast, but it can only see whether a cookie exists, not whether it's valid.
2. **Layout guard** — the `(app)` layout waits for the refresh call, shows a skeleton, and redirects if it fails. This is the real gate.
3. **Server-side** — every protected endpoint verifies the token. **This is the only one that's actually security.** The first two are UX.

Never rely on client-side checks for authorisation. Hiding a button doesn't stop anyone from calling the endpoint.

### Roles

| Role | Can |
|------|-----|
| `LIBRARIAN` | Everything |
| `MEMBER` | Phase 2 — read own borrows and history, browse catalogue |

Phase 1 only issues `LIBRARIAN`. Put the field in from the start anyway; adding a role column to a live auth table is far more annoying than having an unused one.

---

## Password rules

Match these between the zod schema and the backend, or users hit a server error after passing client validation.

| Rule | Value |
|------|-------|
| Minimum length | 12 characters |
| Maximum length | 128 |
| Character classes | None required |
| Blocklist | Common passwords, the user's own email and name |
| Hashing | BCrypt, cost ≥ 10 |

**Length beats complexity.** Forcing a symbol and a digit produces `Password1!` — predictable and weak. A 12-character minimum with no composition rules produces longer, more varied passwords. This follows current NIST guidance rather than the 2005 version most forms still copy.

**Show a strength meter, don't gate on it.** The meter educates; the length minimum enforces.

**Never** truncate silently, block paste, or impose a max below 64 — all three break password managers, and password managers are the single best thing a user can do for their own security.

---

## Security checklist

Before calling auth done:

- [ ] Login and forgot-password respond identically for existing and non-existent accounts
- [ ] Rate limiting on login, signup, forgot-password, and resend-verification
- [ ] Reset tokens: random, hashed at rest, single-use, 30-minute expiry
- [ ] Password reset revokes all refresh tokens
- [ ] Refresh tokens rotate on use; reuse triggers family revocation
- [ ] Refresh cookie is httpOnly, Secure, SameSite
- [ ] CORS allows credentials from the exact frontend origin
- [ ] `next` redirect param validated as an internal path
- [ ] Passwords never logged, never returned, never in error messages
- [ ] Every protected endpoint verifies the token server-side
- [ ] Access token never written to localStorage
